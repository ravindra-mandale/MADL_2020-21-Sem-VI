package edu.rit.priti.tenyearschallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.Button;
import android.content.Intent;
public class MainActivity extends AppCompatActivity {


    String role[]={"Faculty","Student","LabAssistant"};
    Spinner spinner;
    ArrayAdapter<String> arrayAdapter;

    EditText ed1,ed2;
    Button b1,b2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner=findViewById(R.id.spinrole);
        arrayAdapter=new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_item,role);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner.setAdapter(arrayAdapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(),"Selected Role "+role[position],Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(getApplicationContext(),"Nothing is selected",Toast.LENGTH_LONG).show();
            }
        });



        ed1=findViewById(R.id.usertext);
        ed2=findViewById(R.id.passtext);
        b1=findViewById(R.id.blogin);
        b2=findViewById(R.id.bcancel);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String text1,text2,text3;
                text1=ed1.getText().toString();
                text2=ed2.getText().toString();
                text3=spinner.getSelectedItem().toString();
                if(text1.contentEquals("faculty") && text2.contentEquals("faculty") && text3.contentEquals("Faculty"))
                {
                    Intent i=new Intent(MainActivity.this,Faculty.class);
                    startActivity(i);
                }
                if(text1.contentEquals("student") && text2.contentEquals("student") && text3.contentEquals("Student"))
                {
                    Intent i=new Intent(MainActivity.this,Student.class);
                    startActivity(i);
                }
                if(text1.contentEquals("lab") && text2.contentEquals("lab") && text3.contentEquals("LabAssistant"))
                {
                    Intent i=new Intent(MainActivity.this,LabAssistant.class);
                    startActivity(i);
                }
                if (text1.equals(""))
                {
                    ed1.setError("Can't be empty");
                }
                if (text2.equals(""))
                {
                    ed2.setError("Can't be empty");
                }
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v)
                        {
                            ed1.setText(null);
                            ed2.setText(null);
                        }
        });
    }
}