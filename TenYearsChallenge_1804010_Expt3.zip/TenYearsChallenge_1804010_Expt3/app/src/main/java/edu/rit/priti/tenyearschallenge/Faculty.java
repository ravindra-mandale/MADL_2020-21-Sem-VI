package edu.rit.priti.tenyearschallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ImageButton;
import android.content.Intent;
public class Faculty extends AppCompatActivity {

    ImageView image;
    ImageButton imbut;
    Button butback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty);

        image=findViewById(R.id.iview);
        imbut=findViewById(R.id.ibut);
        butback=findViewById(R.id.bback);

        imbut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                image.setImageResource(R.drawable.s2);
            }
        });

        butback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Faculty.this, MainActivity.class);
                startActivity(i);
            }
        });
    }
}