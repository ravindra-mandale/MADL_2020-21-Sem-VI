package edu.ritindia.calcapp.abhicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText et1,et2;
    Button bt1, bt2, bt3, bt4,bt5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1 = findViewById(R.id.editText1);
        et2 = findViewById(R.id.editText2);

        bt1 = findViewById(R.id.btn1);
        bt2 = findViewById(R.id.btn2);
        bt3 = findViewById(R.id.btn3);
        bt4 = findViewById(R.id.btn4);
        bt5 = findViewById(R.id.btn5);

        bt1.setOnClickListener(this);
        bt2.setOnClickListener(this);
        bt3.setOnClickListener(this);
        bt4.setOnClickListener(this);
        bt5.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        int n1,n2,x;
        int id=v.getId();
        switch (id)
        {
            case R.id.btn1 :
                n1 = Integer.parseInt(et1.getText().toString());
                n2 = Integer.parseInt(et2.getText().toString());
                x = n1 + n2;
                Toast.makeText(this, "Addition : " +x, Toast.LENGTH_SHORT).show();
                break;

            case R.id.btn2 :
                n1 = Integer.parseInt(et1.getText().toString());
                n2 = Integer.parseInt(et2.getText().toString());
                x = n1 - n2;
                Toast.makeText(this, "Substraction : " +x, Toast.LENGTH_SHORT).show();
                break;

            case R.id.btn3 :
                n1 = Integer.parseInt(et1.getText().toString());
                n2 = Integer.parseInt(et2.getText().toString());
                x = n1 * n2;
                Toast.makeText(this, "Multiplication : " +x, Toast.LENGTH_SHORT).show();
                break;

            case R.id.btn4 :
                n1 = Integer.parseInt(et1.getText().toString());
                n2 = Integer.parseInt(et2.getText().toString());
                x = n1 / n2;
                Toast.makeText(this, "Division : " +x, Toast.LENGTH_SHORT).show();
                break;

            case R.id.btn5 :
                n1 = Integer.parseInt(et1.getText().toString());
                n2 = Integer.parseInt(et2.getText().toString());
                x = n1 % n2;
                Toast.makeText(this, "Mod : " +x, Toast.LENGTH_SHORT).show();


        }


    }
}