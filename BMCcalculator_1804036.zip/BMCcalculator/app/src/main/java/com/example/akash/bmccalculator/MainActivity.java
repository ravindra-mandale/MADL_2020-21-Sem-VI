package com.example.akash.bmccalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btn1;
    EditText edit1,edit2;
    float a,b;
    float c;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1=findViewById(R.id.button1);
        edit1=findViewById(R.id.et1);
        edit2=findViewById(R.id.et2);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a=Integer.parseInt(edit1.getText().toString());
                b=Integer.parseInt(edit2.getText().toString());
                b=b/100;
                c=a/(b*b);

                if(c<18.0) {
                    Toast.makeText(getApplicationContext(),"BMC (Underfitted) :" +c,Toast.LENGTH_LONG).show();
                }

                else if(25.0<c){
                    Toast.makeText(getApplicationContext(),"BMC (Overfitted) :" +c,Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getApplicationContext(),"BMC (Normal) :" +c,Toast.LENGTH_LONG).show();

                }
            }
        });

    }
}