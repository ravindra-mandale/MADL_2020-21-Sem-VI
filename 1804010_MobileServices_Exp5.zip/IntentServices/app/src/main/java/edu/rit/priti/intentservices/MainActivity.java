package edu.rit.priti.intentservices;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int REQUEST_CALL=1;
    private static final int pic_id = 123;
    Button cal,dial,cont,gal,brows,cam,log;
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==REQUEST_CALL)
        {
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)
            {

                makePhonecall();
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Rejected Permission",Toast.LENGTH_LONG).show();
            }
        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dial = findViewById(R.id.dial_b);
        dial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1 = new Intent(Intent.ACTION_DIAL);
                startActivity(i1);
            }
        });

        cal = findViewById(R.id.call_b);
        cal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                makePhonecall();
            }
        });

        cont=findViewById(R.id.cont_b);
        cont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i2 = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
                startActivity(i2);
            }
        });

        brows=findViewById(R.id.brow_b);
        brows.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i3=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.co.in/webhp"));
                startActivity(i3);
            }
        });

        log=findViewById(R.id.log_b);
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i4=new Intent(Intent.ACTION_VIEW,Uri.parse("content://call_log/calls/"));
                startActivity(i4);
            }
        });

        gal=findViewById(R.id.gal_b);
        gal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i5=new Intent(Intent.ACTION_VIEW,Uri.parse("content://media/external/images/media/"));
                startActivity(i5);
            }
        });

        cam=findViewById(R.id.cam_b);
        cam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i6=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(i6, pic_id);
            }
        });
    }

    protected void onActivityResult(int reqCode, int resultCode, Intent data) {
        super.onActivityResult(reqCode, resultCode, data);
        if (reqCode == pic_id) {

            Bitmap photo = (Bitmap) data.getExtras().get("data");

            Intent intent = new Intent(MainActivity.this, CamImage.class);
            Bundle extras = new Bundle();
            extras.putParcelable("imagebitmap", photo);
            intent.putExtras(extras);
            startActivity(intent);
        }
    }

    private void makePhonecall()
    {
        if(ContextCompat.checkSelfPermission(MainActivity.this,Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.CALL_PHONE},REQUEST_CALL);
        }
        else {
            Intent i1=new Intent(Intent.ACTION_CALL,Uri.parse("tel:7709081054"));
            startActivity(i1);
        }
    }
}