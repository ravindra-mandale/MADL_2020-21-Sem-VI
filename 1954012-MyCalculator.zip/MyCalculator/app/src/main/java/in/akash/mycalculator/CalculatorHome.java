package in.akash.mycalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CalculatorHome extends AppCompatActivity implements View.OnClickListener {

    private EditText textFirstNumber, textSecondNumber;
    private Button buttonAdd, buttonSub, buttonDiv, buttonMul, buttonMod;
    private TextView textResult;
    private Calculator calculator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calculator_home);

        calculator = new Calculator();
        textFirstNumber = findViewById(R.id.editFirst);
        textSecondNumber = findViewById(R.id.editSecond);

        buttonAdd = findViewById(R.id.buttonAdd);
        buttonSub = findViewById(R.id.buttonSub);
        buttonDiv = findViewById(R.id.buttonDiv);
        buttonMul = findViewById(R.id.buttonMul);
        buttonMod = findViewById(R.id.buttonMod);

        buttonAdd.setOnClickListener(this);
        buttonSub.setOnClickListener(this);
        buttonDiv.setOnClickListener(this);
        buttonMul.setOnClickListener(this);
        buttonMod.setOnClickListener(this);

        textResult = findViewById(R.id.textResult);
    }

    public boolean isEmpty(EditText textBox)
    {
        return textBox.getText().toString().trim().length() == 0;
    }

    @Override
    public void onClick(View v) {

        float numFirst = 0.0f, numSecond = 0.0f;

        if (!isEmpty(textFirstNumber))
        {
            numFirst = Float.parseFloat(textFirstNumber.getText().toString());
        }
        if (!isEmpty(textSecondNumber))
        {
            numSecond = Float.parseFloat(textSecondNumber.getText().toString());
        }
        float result = 0.0f;

        switch(v.getId())
        {
            case R.id.buttonAdd:
                result = calculator.getAddition(numFirst, numSecond);
                break;

            case R.id.buttonDiv:
                result = calculator.getDivision(numFirst, numSecond);
                break;

            case R.id.buttonMod:
                result = calculator.getModulus(numFirst, numSecond);
                break;

            case R.id.buttonMul:
                result = calculator.getMultiplication(numFirst, numSecond);
                break;

            case R.id.buttonSub:
                result = calculator.getSubtraction(numFirst, numSecond);
                break;

            default:
                result = -1.0f;
                break;
        }
        textResult.setText(String.valueOf(result));
    }
}

class Calculator
{
    float lastResult;
    public Calculator()
    {
        lastResult = 0.0f;
    }
    public float getAddition(float first, float second)
    {
        lastResult = first + second;
        return first + second;
    }
    public float getSubtraction(float first, float second)
    {
        lastResult = first - second;
        return first - second;
    }
    public float getMultiplication(float first, float second)
    {
        lastResult = first * second;
        return first * second;
    }
    public float getDivision(float first, float second)
    {
        lastResult = first / second;
        return first / second;
    }
    public float getModulus(float first, float second)
    {
        lastResult = first % second;
        return first % second;
    }
}