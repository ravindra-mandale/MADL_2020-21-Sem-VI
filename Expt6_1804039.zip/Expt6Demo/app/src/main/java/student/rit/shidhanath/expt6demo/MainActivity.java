package student.rit.shidhanath.expt6demo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //btn=findViewById(R.id.button);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            NotificationChannel channel=new NotificationChannel("MyNotification","MyNotification", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager=(NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            manager.createNotificationChannel(channel);
        }





//        btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                NotificationCompat.Builder notificationbuilder=new NotificationCompat.Builder(MainActivity.this,"MyNotifiaction");
//                notificationbuilder.setContentTitle("MyNotification");
//                notificationbuilder.setContentText("Hello Expt 6 Demo ");
//                notificationbuilder.setSmallIcon(R.drawable.ic_baseline_notifications_24);
//                notificationbuilder.setPriority(NotificationCompat.PRIORITY_DEFAULT);
//                notificationbuilder.setAutoCancel(true);
//
//                NotificationManagerCompat managerCompat=NotificationManagerCompat.from(MainActivity.this);
//                Notification notification=notificationbuilder.build();
//                managerCompat.notify(1,notification);
//            }
//        });

    }

    public void showNotification(View view) {
        NotificationCompat.Builder notificationbuilder=new NotificationCompat.Builder(this);
               notificationbuilder.setContentTitle("MyNotification");
               notificationbuilder.setContentText("Hello Expt 6 Demo ");
               notificationbuilder.setSmallIcon(R.drawable.ic_baseline_notifications_24);
               notificationbuilder.setPriority(NotificationCompat.PRIORITY_DEFAULT);
               notificationbuilder.setAutoCancel(true);

                NotificationManagerCompat managerCompat=NotificationManagerCompat.from(MainActivity.this);
                Notification notification=notificationbuilder.build();
                managerCompat.notify(1,notification);
    }
}