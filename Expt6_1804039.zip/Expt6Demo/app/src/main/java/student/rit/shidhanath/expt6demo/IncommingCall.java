package student.rit.shidhanath.expt6demo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class IncommingCall extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Toast.makeText(context,"You are getting call ", Toast.LENGTH_LONG).show();
    }
}
