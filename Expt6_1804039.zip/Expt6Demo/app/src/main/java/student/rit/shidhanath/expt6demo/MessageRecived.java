package student.rit.shidhanath.expt6demo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.widget.Toast;

public class MessageRecived extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

        Bundle bundle=intent.getExtras();
       Object O[]=(Object[]) bundle.get("pdus");

        SmsMessage message= SmsMessage.createFromPdu((byte[]) O[0]);
        String sender=message.getDisplayOriginatingAddress();
        String msg=message.getMessageBody();

        Toast.makeText(context,sender+" you are getting Message "+msg,Toast.LENGTH_LONG).show();
    }
}
