package edu.ritindia.ruturaj.calculatorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText ed_no1 ,ed_no2 ;
    Button btn_add, btn_sub, btn_multi, btn_div;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed_no1 = findViewById(R.id.editTextNumber1);
        ed_no2 = findViewById(R.id.editTextNumber2);
        btn_add = findViewById(R.id.button1);
        btn_sub = findViewById(R.id.button2);
        btn_multi = findViewById(R.id.button3);
        btn_div = findViewById(R.id.button4);
        btn_add.setOnClickListener(this);
        btn_sub.setOnClickListener(this);
        btn_multi.setOnClickListener(this);
        btn_div.setOnClickListener(this);

    }
   public void OnClick(View v)
   {
       int id = v.getId();
       int num1 = Integer.parseInt(ed_no1.getText().toString());
       int num2 = Integer.parseInt(ed_no2.getText().toString());

       switch (id)
       {
           case R.id.button1:
                Toast.makeText(getApplicationContext(),"Addition is "+(num1 + num2),Toast.LENGTH_LONG).show();
                break;
           case R.id.button2:
               Toast.makeText(getApplicationContext(),"Subtraction is "+(num1 - num2),Toast.LENGTH_LONG).show();
               break;
           case R.id.button3:
               Toast.makeText(getApplicationContext(),"Multiplication is "+(num1 * num2),Toast.LENGTH_LONG).show();
               break;
           case R.id.button4:
               Toast.makeText(getApplicationContext(),"Division is "+(num1 / num2),Toast.LENGTH_LONG).show();
               break;
       }

   }
}