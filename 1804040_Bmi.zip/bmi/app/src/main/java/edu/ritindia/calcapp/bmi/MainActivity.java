package edu.ritindia.calcapp.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity  {
    EditText w,h;
    Button cal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        w=findViewById(R.id.weight);
        h=findViewById(R.id.height);
        cal=findViewById(R.id.Calculate);

        cal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n1,n2;
                float cal;

                n1=Integer.parseInt(w.getText().toString());
                n2=Integer.parseInt(h.getText().toString());
                cal=n1*10000/(n2*n2);
                cal=Float.parseFloat(String.valueOf(cal));
                Toast.makeText(getApplicationContext(),
                        "BMI"+cal,
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}