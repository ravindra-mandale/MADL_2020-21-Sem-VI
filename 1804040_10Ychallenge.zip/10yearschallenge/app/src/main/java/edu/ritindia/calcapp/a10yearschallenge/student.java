package edu.ritindia.calcapp.a10yearschallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class student extends AppCompatActivity {
    Button studentc, studentout;
    ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        studentc = findViewById(R.id.studentchallenge);
        studentout = findViewById(R.id.studentlogout);
        img = findViewById(R.id.imageView);
        studentout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(student.this, MainActivity.class);
                startActivity(i);
            }
        });
        studentc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                img.setImageResource(R.drawable.oldstudent);

            }


        });
    }
}



