package com.example.bmicalculatorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button calc;
    EditText height,weight;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        calc=findViewById(R.id.calculate);
        height=findViewById(R.id.height);
        weight=findViewById(R.id.weight);
        calc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(weight.getText().toString()!=""&&height.getText().toString()!="") {
                    String msg="";
                    float hei = Float.parseFloat(height.getText().toString());
                    float wei = Float.parseFloat(weight.getText().toString());
                    float bmi = (wei / hei / hei)*10000;
                    if(bmi<18.5)
                    {
                        msg+=bmi+" Underweight.";
                    }
                    if(bmi>18.5&&bmi<25)
                    {
                        msg+=bmi+" Normal.";
                    }
                    if(bmi>25.0&&bmi<30)
                    {
                        msg+=bmi+" Overweight.";
                    }
                    if(bmi>30)
                    {
                        msg+=bmi+" Obesity.";
                    }
                    System.out.println(bmi);
                    System.out.println(msg);
                    Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
                    height.setText("");
                    weight.setText("");
                }
            }
        });
    }
}