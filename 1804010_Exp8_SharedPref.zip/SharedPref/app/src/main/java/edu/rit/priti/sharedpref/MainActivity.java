package edu.rit.priti.sharedpref;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static java.lang.String.valueOf;

public class MainActivity extends AppCompatActivity {

    EditText ed1,ed2,ed3;
    Button b1,b2,b3;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed1=findViewById(R.id.edt1);
        ed2=findViewById(R.id.edt2);
        ed3=findViewById(R.id.edt3);

       /*if(sp.contains("Name"))
        {
            ed1.setText(sp.getString("Name",null));
        }
        if(sp.contains("Adhar Card Number"))
        {

            ed3.setText(valueOf(sp.getInt("Adhar Card Number",0)));
        }
      if(sp.contains("Pan-Card Number"))
        {

            ed2.setText(valueOf(sp.getInt("Pan-Card Number",0)));
        }*/

        b1=findViewById(R.id.button1);
        b2=findViewById(R.id.button2);
        b3=findViewById(R.id.button3);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sp=getSharedPreferences("Person",MODE_PRIVATE);
                String name=ed1.getText().toString();
                int adhar=Integer.parseInt(ed3.getText().toString());
                int pan=Integer.parseInt(ed2.getText().toString());
                SharedPreferences.Editor editor=sp.edit();
                editor.putString("Name",name);
                editor.putInt("Adhar Card Number",adhar);
                editor.putInt("Pan-Card Number",pan);
                editor.commit();
                Toast.makeText(getApplicationContext(),"Your Data is Stored",Toast.LENGTH_LONG).show();
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int ad=0,pc=0;
                String nm=null;

                if(sp.contains("Name"))
                {
                    nm=sp.getString("Name",null);
                }
                if(sp.contains("Adhar Card Number"))
                {
                    ad=sp.getInt("Adhar Card Number",0);
                }
                if(sp.contains("Pan-Card Number"))
                {
                    pc=sp.getInt("Pan-Card Number",0);
                }
                Toast.makeText(getApplicationContext(), nm+" "+"  AdharCard Number: "+ad+"  PanCard Number: "+pc, Toast.LENGTH_LONG).show();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor edtr=sp.edit();
                edtr.clear();

                Toast.makeText(getApplicationContext(), "Data Is Cleared", Toast.LENGTH_LONG).show();
            }
        });
    }
}