package edu.rit.aishwarya.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         EditText e1,e2;
         Button b1;
         e1=findViewById(R.id.p1);
         e2=findViewById(R.id.p2);
         b1=findViewById(R.id.button1);

         b1.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
            String w=e1.getText().toString();
            String h= e2.getText().toString();

            int num1=Integer.parseInt(w);
            int num2=Integer.parseInt(h);

            int res=num1/num2*num2;
                 Toast.makeText(MainActivity.this,"BMI RESULT IS :" + res,Toast.LENGTH_SHORT).show();
             }
         });


    }
}