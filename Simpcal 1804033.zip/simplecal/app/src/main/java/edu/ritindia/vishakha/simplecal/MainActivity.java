package edu.ritindia.vishakha.simplecal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener {
    EditText textno1, textno2;
    Button btn1, btn2, btn3, btn4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textno1 = findViewById(R.id.textno1);
        textno2 = findViewById(R.id.textno2);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);

        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
    }

    public void onClick(View v) {

        int id = v.getId();
        int no1 = Integer.parseInt(textno1.getText().toString());
        int no2 = Integer.parseInt(textno2.getText().toString());

        switch (id) {


            case R.id.btn1:
                Toast.makeText(getApplicationContext(), "addition is  " + (no1 + no2), Toast.LENGTH_LONG).show();
                break;

            case R.id.btn2:
                Toast.makeText(getApplicationContext(), "substraction is  " + (no1 - no2), Toast.LENGTH_LONG).show();
                break;

            case R.id.btn3:
                Toast.makeText(getApplicationContext(), "multiplication is  " + (no1 * no2), Toast.LENGTH_LONG).show();
                break;

            case R.id.btn4:
                Toast.makeText(getApplicationContext(), "division is  " + (no1 / no2), Toast.LENGTH_LONG).show();
                break;

        }
    }
}
