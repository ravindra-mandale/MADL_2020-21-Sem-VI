package com.exp2.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity  {

    EditText editTextNumber1,editTextNumber2;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        button=findViewById(R.id.button);
        editTextNumber1=findViewById(R.id.editTextNumber1);
        editTextNumber2=findViewById(R.id.editTextNumber2);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double num1,num2,c,d;
                num1=Integer.parseInt(editTextNumber1.getText().toString());
                num2=Integer.parseInt(editTextNumber2.getText().toString());
                d=num2*num2*0.0001;
                c=num1/d;
                if(c<18.5)
                {
                    Toast.makeText(getApplicationContext(),"Your BMI Result   "+c+" (Underweight)",Toast.LENGTH_LONG).show();
                }
                else if(c>=18.5 && c<=24.9)
                {
                    Toast.makeText(getApplicationContext(),"Your BMI Result   "+c+" (Normal)",Toast.LENGTH_LONG).show();
                }
                else if (c>=25 && c<=29)
                {
                    Toast.makeText(getApplicationContext(),"Your BMI Result   "+c+" (Overweight)",Toast.LENGTH_LONG).show();
                }
                else if (c>=30)
                {
                    Toast.makeText(getApplicationContext(),"Your BMI Result   "+c+" (Obesity)",Toast.LENGTH_LONG).show();
                }
        }
    });







    }
}