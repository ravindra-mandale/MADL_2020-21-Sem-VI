package edu.madlab.exp4.activityandlifecycleexp4;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageButton button_ipl;
    ImageView imageView_main;
    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        builder = new AlertDialog.Builder(this);


        Log.d("OnCreate","Activity Created");

        imageView_main=findViewById(R.id.imageView_main);
        button_ipl=findViewById(R.id.imageButton_ipl);
        registerForContextMenu(button_ipl);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menuss,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected( MenuItem item) {

        int id=item.getItemId();
        switch (id)
        {
            case R.id.omenu1:
                Toast.makeText(getApplicationContext(),"Ipl Teams",Toast.LENGTH_LONG).show();
                imageView_main.setImageResource(R.drawable.teams);
                return super.onContextItemSelected(item);
            case R.id.omenu2:
                Toast.makeText(getApplicationContext(),"Captains",Toast.LENGTH_LONG).show();
                imageView_main.setImageResource(R.drawable.captains);
                return super.onContextItemSelected(item);
            case R.id.omenu3:
                Toast.makeText(getApplicationContext(),"Owners",Toast.LENGTH_LONG).show();
                imageView_main.setImageResource(R.drawable.owners);
                return super.onContextItemSelected(item);
            case R.id.omenu4:
                Toast.makeText(getApplicationContext(),"Upper Manegers Team",Toast.LENGTH_LONG).show();
                imageView_main.setImageResource(R.drawable.uppermaneger);
                return super.onContextItemSelected(item);
            case R.id.omenu5:
                Toast.makeText(getApplicationContext(),"Winners History",Toast.LENGTH_LONG).show();
                imageView_main.setImageResource(R.drawable.winners);
                return super.onContextItemSelected(item);
            case R.id.omenu6:




                builder.setMessage("Do you want to close this application ?")
                        .setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                finish();
                                Toast.makeText(getApplicationContext(),"Thank You",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                                dialog.cancel();
                                 
                            }
                        });

                AlertDialog alert = builder.create();

                alert.setTitle("Exit From Application");
                alert.show();

                return super.onContextItemSelected(item);
            default:
                return super.onOptionsItemSelected(item);
        }

    }



    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.contextmenu,menu);

    }

    @Override
    public boolean onContextItemSelected( MenuItem item) {
        int id=item.getItemId();
        switch (id)
        {
            case R.id.menu1:
                Toast.makeText(getApplicationContext(),"Mumbai Indians",Toast.LENGTH_LONG).show();
                Intent i1=new Intent(MainActivity.this,mi.class);
                startActivity(i1);
                return super.onContextItemSelected(item);
            case R.id.menu2:
                Toast.makeText(getApplicationContext(),"Chennai Super Kings",Toast.LENGTH_LONG).show();
                Intent i2=new Intent(MainActivity.this,csk.class);
                startActivity(i2);
                return super.onContextItemSelected(item);
            case R.id.menu3:
                Toast.makeText(getApplicationContext(),"Rajasthan Royals",Toast.LENGTH_LONG).show();
                Intent i3=new Intent(MainActivity.this,rr.class);
                startActivity(i3);
                return super.onContextItemSelected(item);
            case R.id.menu4:
                Toast.makeText(getApplicationContext(),"Royal Challengers Banglore",Toast.LENGTH_LONG).show();
                Intent i4=new Intent(MainActivity.this,rcb.class);
                startActivity(i4);
                return super.onContextItemSelected(item);
            case R.id.menu5:
                Toast.makeText(getApplicationContext(),"Sunrisers Hyderabad",Toast.LENGTH_LONG).show();
                Intent i5=new Intent(MainActivity.this,srh.class);
                startActivity(i5);
                return super.onContextItemSelected(item);
            default:
                return super.onContextItemSelected(item);
        }

    }

    //Activity Lifecycyle

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("OnStart","Activity Started");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("onResume","Activity Resumed");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("onPause","Activity Paused");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("onStop","Activity Stopped");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("onDestroy","Activity Destroyed");
    }
}