package edu.madlab.exp4.activityandlifecycleexp4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class mi extends AppCompatActivity {
    ImageButton button_mi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mi);
        button_mi=findViewById(R.id.button_mi);
        button_mi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mi =new Intent(mi.this,MainActivity.class);
                startActivity(mi);
            }
        });
    }
}