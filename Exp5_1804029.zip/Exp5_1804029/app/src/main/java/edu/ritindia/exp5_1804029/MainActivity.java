package edu.ritindia.exp5_1804029;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText Ed;
    Button call,dialpad,contact,browser,camera,calllog,gallary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Ed=findViewById(R.id.Edittext);
        call=findViewById(R.id.button);
        dialpad=findViewById(R.id.button2);
        contact=findViewById(R.id.button3);
        browser=findViewById(R.id.button4);
        calllog=findViewById(R.id.button5);
        gallary=findViewById(R.id.button6);
        camera=findViewById(R.id.button7);

        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v.getId()==R.id.button)
                {
                    Intent i=new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Ed.getText().toString()));
                    startActivity(i);
                }

            }
        });


        dialpad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v.getId()==R.id.button2)
                {
                    Intent i2=new Intent(Intent.ACTION_DIAL,Uri.parse("tel:91"));
                    startActivity(i2);
                }
            }
        });

        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v.getId()==R.id.button3)
                {
                    Intent i3=new Intent(Intent.ACTION_VIEW,Uri.parse("content://contacts/people/"));
                    startActivity(i3);
                }
            }
        });

        browser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v.getId()==R.id.button4)
                {
                    Intent i4=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/"));
                    startActivity(i4);
                }
            }
        });

         calllog.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 if (v.getId()==R.id.button5)
                 {
                     Intent i5=new Intent(Intent.ACTION_VIEW,Uri.parse("content://call_log/calls/"));
                     startActivity(i5);
                 }
             }
         });

         gallary.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 if (v.getId()==R.id.button6)
                 {
                     Intent i6=new Intent(Intent.ACTION_VIEW,Uri.parse("content://media/external/images/media/"));
                     startActivity(i6);
                 }
             }
         });

         camera.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 if (v.getId()==R.id.button7)
                 {
                     Intent i7=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                     startActivity(i7);
                 }
             }
         });



    }
}