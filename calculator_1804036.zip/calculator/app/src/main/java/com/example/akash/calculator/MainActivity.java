package com.example.akash.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.net.wifi.p2p.WifiP2pManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btn1,btn2,btn3,btn4;
    int a;
    int b;
    int ans;
    TextView ed1,ed2,tv1;


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.et1);
        ed2=findViewById(R.id.et2);
        btn1=findViewById(R.id.btnadd);
        btn2=findViewById(R.id.btnsub);
        btn3=findViewById(R.id.btnmul);
        btn4=findViewById(R.id.btndiv);
        tv1=findViewById(R.id.tv);

        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
            switch(v.getId()){
                case R.id.btnadd:
                    a = Integer.parseInt(ed1.getText().toString());
                    b = Integer.parseInt(ed2.getText().toString());
                    ans=a+b;
                    tv1.setText("Addition is "+ans);
                    Toast.makeText(getApplicationContext(), "Addition is "+ans, Toast.LENGTH_LONG).show();
                    break;
                case R.id.btnsub:
                    a = Integer.parseInt(ed1.getText().toString());
                    b = Integer.parseInt(ed2.getText().toString());
                    ans=a-b;
                    tv1.setText("Subtraction is "+ans);
                    Toast.makeText(getApplicationContext(), "Subtraction is "+ans, Toast.LENGTH_LONG).show();
                    break;
                case R.id.btnmul:
                    a = Integer.parseInt(ed1.getText().toString());
                    b = Integer.parseInt(ed2.getText().toString());
                    ans=a*b;
                    tv1.setText("Multiplication is "+ans);
                    Toast.makeText(getApplicationContext(), "Multiplication is "+ans, Toast.LENGTH_LONG).show();
                    break;
                case R.id.btndiv:
                    a = Integer.parseInt(ed1.getText().toString());
                    b = Integer.parseInt(ed2.getText().toString());
                    ans=a/b;
                    tv1.setText("Division is "+ans);
                    Toast.makeText(getApplicationContext(), "Division is "+ans, Toast.LENGTH_LONG).show();
                    break;
            }
    }
}