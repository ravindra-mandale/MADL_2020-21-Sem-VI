package edu.rit.sanajana.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText e1,e2;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=findViewById(R.id.edittext);
        e2=findViewById(R.id.edittext1);
        b1=findViewById(R.id.button1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1=e1.getText().toString();
                String s2=e2.getText().toString();

                int n1=Integer.parseInt(s1);
                int n2=Integer.parseInt(s2);

                int result=n1/n2*n2;
                Toast.makeText(getApplicationContext(),"BMI is"+result,Toast.LENGTH_LONG).show();
            }
        });
    }
}