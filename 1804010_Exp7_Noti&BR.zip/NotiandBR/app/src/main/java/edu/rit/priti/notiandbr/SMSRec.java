package edu.rit.priti.notiandbr;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.widget.Toast;

public class SMSRec extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle b=intent.getExtras();
        Object o[]=(Object[])b.get("pdus");
        SmsMessage message=SmsMessage.createFromPdu((byte[]) o[0]);
        String senderno=message.getOriginatingAddress();
        String msg=message.getMessageBody();
        Toast.makeText(context,senderno+" sent you message: "+msg,Toast.LENGTH_LONG).show();

    }
}
