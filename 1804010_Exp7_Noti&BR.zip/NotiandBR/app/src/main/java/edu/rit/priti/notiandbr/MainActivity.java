package edu.rit.priti.notiandbr;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    private BatteryStat bt=new BatteryStat();
    private IntentFilter intentFilter=new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
    //ImageButton im;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)
        {
            NotificationChannel nc=new NotificationChannel("RIT Channel","RIT Channel", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager ng=(NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            ng.createNotificationChannel(nc);

        }
    }

    public void popup(View v)
    {
        NotificationCompat.Builder nb=new NotificationCompat.Builder(getApplicationContext(),"RIT Channel");
        nb.setSmallIcon(R.drawable.ic_baseline_notifications_24);
        nb.setContentTitle("Notification Alert");
        nb.setContentText("This is Notification Detail");
        nb.setPriority(NotificationCompat.PRIORITY_DEFAULT);
        nb.setAutoCancel(true);
        NotificationManagerCompat nm= NotificationManagerCompat.from(MainActivity.this);
        Notification notification=nb.build();
        nm.notify(123,notification);

    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        registerReceiver(bt,intentFilter);
    }

    @Override
    protected void onPause() {
        unregisterReceiver(bt);
        super.onPause();

    }
}