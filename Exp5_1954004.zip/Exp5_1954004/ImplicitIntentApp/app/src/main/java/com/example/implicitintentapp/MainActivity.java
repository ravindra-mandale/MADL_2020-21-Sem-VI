package com.example.implicitintentapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.net.URI;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    Button call,dialpad,contact,browser,calllog,gallery,camera;
    EditText phoneNum;
    private int CAMERA_PIC_REQUEST = 7;
    public void openGallery(int SELECT_FILE1) {

        Intent intent = new Intent();
        intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(
                Intent.createChooser(intent, "Select file to upload "),
                SELECT_FILE1);

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        phoneNum=findViewById(R.id.MobileNumber);
        call=findViewById(R.id.buttonCall);
        dialpad=findViewById(R.id.buttonDialpad);
        contact=findViewById(R.id.buttonContact);
        browser=findViewById(R.id.buttonBrowser);
        calllog=findViewById(R.id.buttonCallLog);
        gallery=findViewById(R.id.buttonGallery);
        camera=findViewById(R.id.buttonCamera);
        String no=phoneNum.getText().toString();
        int length=no.length();
        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:" + phoneNum));
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent,null);
                }*/
                Log.d("Number",no);
                /*Intent intent = new Intent(Intent.ACTION_CALL, Uri.fromParts("tel:" ,no,null));
                startActivity(intent);*/
                Intent in = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+no));
                try {
                    startActivity(in);
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(getApplicationContext(), "Could not find an activity to place the call.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialpad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //if(length==10) {
                    Intent dialIntent = new Intent(Intent.ACTION_DIAL);
                    dialIntent.setData(Uri.parse("tel:" + no));
                    startActivity(dialIntent);

                //EditText e = (EditText)findViewById(R.id.editText);
                Uri u = Uri.parse("tel:" + no.toString());
                Intent i = new Intent(Intent.ACTION_DIAL, u);
                phoneNum.setText(null);
                /*}
                else  {
                    Toast.makeText(getApplicationContext(),"Enter valid no",Toast.LENGTH_SHORT).show();
                    phoneNum.setText(null);
                }*/
            }
        });
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                if(length==10) {
                    /*Intent dialIntent = new Intent(Intent.ACTION_DIAL);
                    dialIntent.setData(Uri.parse("tel:" + no));
                    startActivity(dialIntent);*/
                    /*startActivity(new Intent(Intent.ACTION_CALL,Uri.fromParts("tel:",no,null)));
                    phoneNum.setText(null);*/
                    Intent intent= new Intent(Intent.ACTION_PICK,  ContactsContract.Contacts.CONTENT_URI);

                    startActivityForResult(intent, 1);
                /*}
                else  {
                    Toast.makeText(getApplicationContext(),"Enter valid no",Toast.LENGTH_SHORT).show();
                    phoneNum.setText(null);
                }*/
            }
        });
        browser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW,Uri.parse("http://www.google.com"));
                startActivity(browserIntent);
            }
        });
        calllog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    Intent logIntent = new Intent();
                    logIntent.setAction(Intent.ACTION_VIEW);
                    logIntent.setType(CallLog.Calls.CONTENT_TYPE);
                    startActivity(logIntent);
            }
        });
        gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(android.content.Intent.ACTION_VIEW);
                intent.setType("image/*");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(takePictureIntent, CAMERA_PIC_REQUEST);
            }
        });
    }
}