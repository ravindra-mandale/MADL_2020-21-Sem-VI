package com.example.collegeapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class StudentDashboard extends AppCompatActivity {

    Button logoutBtnStudent, changeStudent;
    ImageView imageView;
    int cnt=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_dashboard);

        logoutBtnStudent = findViewById(R.id.logoutStudent);
        imageView = findViewById(R.id.imageViewStudent);

        changeStudent = findViewById(R.id.changeStudent);

        changeStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(cnt%2==0){
                    imageView.setImageResource(R.drawable.downloadstudent);
                    cnt++;
                }else {
                    imageView.setImageResource(R.drawable.download);
                    cnt++;
                }
            }
        });


        logoutBtnStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
            }
        });

    }
}