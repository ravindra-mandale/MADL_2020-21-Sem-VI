package com.example.collegeapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class LabAssistantDashboard extends AppCompatActivity {

    Button logoutBtnLab, changeLab;
    ImageView imageViewLab;
    int cnt=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab_assistant_dashboard);

        logoutBtnLab = findViewById(R.id.logoutLab);
        imageViewLab = findViewById(R.id.imageViewlab);
        changeLab = findViewById(R.id.changeLab);
        //int cnt=0;

        changeLab.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if(cnt%2==0){
                    imageViewLab.setImageResource(R.drawable.labten);
                    cnt++;
                }else {
                    imageViewLab.setImageResource(R.drawable.lab);
                    cnt++;
                }


            }
        });



        logoutBtnLab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
            }
        });
    }
}