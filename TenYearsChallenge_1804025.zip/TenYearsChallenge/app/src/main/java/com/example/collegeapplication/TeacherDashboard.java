package com.example.collegeapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class TeacherDashboard extends AppCompatActivity {

    Button logoutBtnTeacher,changeTeacher;
    ImageView imageViewTeacher;
    int cnt=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_dashboard);

        logoutBtnTeacher = findViewById(R.id.logoutTeacher);
        changeTeacher = findViewById(R.id.changeTeacher);
        imageViewTeacher = findViewById(R.id.imageViewTeacher);

        changeTeacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(cnt%2==0){
                    imageViewTeacher.setImageResource(R.drawable.downloadteacherten);
                    cnt++;
                }else {
                    imageViewTeacher.setImageResource(R.drawable.downloadteacher);
                    cnt++;
                }


            }
        });


        logoutBtnTeacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
            }
        });

    }
}