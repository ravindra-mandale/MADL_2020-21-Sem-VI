package com.example.expt4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button);
        registerForContextMenu(b1);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.mymenu,menu);
        // getMenuInflater().inflate(R.menu.mymenu,menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {

        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.mymenu,menu);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        switch (id)
        {
            case R.id.menu1:
                Intent i= new Intent(MainActivity.this,MainActivity2.class);
                startActivity(i);
                return true;
            case R.id.menu2:
                Intent i1= new Intent(MainActivity.this,MainActivity3.class);
                startActivity(i1);
                return true;
            case R.id.menu3:
                Intent i2= new Intent(MainActivity.this,MainActivity4.class);
                startActivity(i2);
                return true;
            case R.id.menu4:
                Intent i3= new Intent(MainActivity.this,MainActivity5.class);
                startActivity(i3);
                return true;
            default:
                return super.onOptionsItemSelected(item);



        }
        //return super.onContextItemSelected(item);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        switch (id)
        {
            case R.id.menu1:
                Intent i= new Intent(MainActivity.this,MainActivity2.class);
                startActivity(i);
                return true;
            case R.id.menu2:
                Intent i1= new Intent(MainActivity.this,MainActivity3.class);
                startActivity(i1);
                return true;
            case R.id.menu3:
                Intent i2= new Intent(MainActivity.this,MainActivity4.class);
                startActivity(i2);
                return true;
            case R.id.menu4:
                Intent i3= new Intent(MainActivity.this,MainActivity5.class);
                startActivity(i3);
                return true;
            default:
                return super.onOptionsItemSelected(item);



        }
        // return super.onOptionsItemSelected(item);
    }
}