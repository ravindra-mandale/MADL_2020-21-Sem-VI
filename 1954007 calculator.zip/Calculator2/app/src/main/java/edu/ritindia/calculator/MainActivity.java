package edu.ritindia.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText editText1;
    EditText editText2;

    Button bt1,bt2,bt3,bt4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initilization of objects
        editText1=findViewById(R.id.text1);
        editText2=findViewById(R.id.text3);
        bt1=findViewById(R.id.button1);
        bt2=findViewById(R.id.button2);
        bt3=findViewById(R.id.button3);
        bt4=findViewById(R.id.button4);

        //Added listner to Each button
        bt1.setOnClickListener(this);
        bt2.setOnClickListener(this);
        bt3.setOnClickListener(this);
        bt4.setOnClickListener(this);


    }
    public void onClick(View v)
    {
        int id=v.getId();

        //Converted String to Integer
        int num1=Integer.parseInt(editText1.getText().toString());
        int num2=Integer.parseInt(editText2.getText().toString());
        switch(id)
        {
            case R.id.button1:
                Toast.makeText(MainActivity.this,"Addition is "+(num1+num2), Toast.LENGTH_LONG).show();
                break;
            case R.id.button2:
                Toast.makeText(getApplicationContext(),"Substraction is "+(num1-num2), Toast.LENGTH_LONG).show();
                break;
            case R.id.button3:
                Toast.makeText(getApplicationContext(),"Division is "+(num1/num2), Toast.LENGTH_LONG).show();
                break;
            case R.id.button4:
                Toast.makeText(getApplicationContext(),"Multiplication is "+(num1*num2), Toast.LENGTH_LONG).show();
                break;
        }
    }
}