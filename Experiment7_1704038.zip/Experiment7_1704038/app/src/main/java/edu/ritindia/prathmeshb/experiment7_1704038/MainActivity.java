package edu.ritindia.prathmeshb.experiment7_1704038;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView textView1;

    @RequiresApi(api = Build.VERSION_CODES.M)


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView1 =findViewById(R.id.textView);

        TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

        String simcountryiso = tm.getSimCountryIso();
        String simoperatorname = tm.getSimOperatorName();

        String networkopname=tm.getNetworkOperatorName();
        String networkCountryISO=tm.getNetworkCountryIso();
        String strphoneType="";

        int phoneType=tm.getPhoneType();

        switch (phoneType)
        {
            case (TelephonyManager.PHONE_TYPE_CDMA):
                strphoneType="CDMA";
                break;
            case (TelephonyManager.PHONE_TYPE_GSM):
                strphoneType="GSM";
                break;
            case (TelephonyManager.PHONE_TYPE_NONE):
                strphoneType="NONE";
                break;
        }

        boolean isRoaming=tm.isNetworkRoaming();

        String info="Your Phone Details : \n";

        info+="\n\n Network Country ISO: "+networkCountryISO;

        info+="\n\n network Operator name: "+ networkopname;

        info+="\n\n Phone Network Type: "+strphoneType;
        info+="\n\n In Roaming?? : "+isRoaming;

        info+="\n\n SIM Country ISO: "+simcountryiso;
        info+="\n\n sim operator name: "+ simoperatorname;

        textView1.setText(info);

    }

}
