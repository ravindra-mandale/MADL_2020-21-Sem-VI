package edu.rit.priti.AudioPlayer;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import edu.rit.priti.exp5services.R;

public class MainActivity extends AppCompatActivity {

    Button st,p,sp;
    MediaPlayer mp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        st = findViewById(R.id.b1);
        p=findViewById(R.id.b2);
        sp=findViewById(R.id.b3);

        mp= MediaPlayer.create(MainActivity.this,R.raw.song);

        st.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.start();
               
            }
        });
        p.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.pause();
                Toast.makeText(getApplicationContext(),"Song is Paused",Toast.LENGTH_LONG).show();
            }
        });
        sp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.stop();
                Toast.makeText(getApplicationContext(),"Song is Stopped",Toast.LENGTH_LONG).show();
            }
        });

    }

}