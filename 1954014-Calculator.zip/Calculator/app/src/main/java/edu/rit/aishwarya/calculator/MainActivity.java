package edu.rit.aishwarya.calculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    Button bt1,bt2,bt3,bt4;
    EditText num1,num2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt1 = findViewById(R.id.b1);
        bt2 = findViewById(R.id.b2);
        bt3 = findViewById(R.id.b3);
        bt4 = findViewById(R.id.b4);
        num1 = findViewById(R.id.num1);
        num2 = findViewById(R.id.num2);

        bt1.setOnClickListener(this);
        bt2.setOnClickListener(this);
        bt3.setOnClickListener(this);
        bt4.setOnClickListener(this);

    }
    public void onClick(View v)
    {
        int id=v.getId();
        int num3=Integer.parseInt(num1.getText().toString());
        int num4=Integer.parseInt(num2.getText().toString());
        switch (id)
        {
            case R.id.b1:
                Toast.makeText(getApplicationContext(),"ADDITION IS:"+(num3+num4),Toast.LENGTH_LONG).show();
                break;

            case R.id.b2:
                Toast.makeText(getApplicationContext(),"SUBTRACTION IS:"+(num3-num4),Toast.LENGTH_LONG).show();
                break;

            case R.id.b3:
                Toast.makeText(getApplicationContext(),"MULTIPLICATION IS:"+(num3*num4),Toast.LENGTH_LONG).show();
                break;

            case R.id.b4:
                Toast.makeText(getApplicationContext(),"DIVISION IS:"+(num3/num4),Toast.LENGTH_LONG).show();
                break;
        }
    }
}