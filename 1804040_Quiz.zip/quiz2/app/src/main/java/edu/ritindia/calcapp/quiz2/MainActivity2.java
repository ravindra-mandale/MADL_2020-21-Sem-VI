package edu.ritindia.calcapp.quiz2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity2 extends AppCompatActivity {
    RadioButton radioButton;
    RadioGroup radioGroup;
    FloatingActionButton floatingActionButton;
    Button button;
    Intent I1;
    int count;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        floatingActionButton=findViewById(R.id.floatingActionButton2);
        radioGroup=findViewById(R.id.radiogroup2);
        button=findViewById(R.id.button2);
        I1=getIntent();
        count=I1.getIntExtra("count",0);

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id=radioGroup.getCheckedRadioButtonId();
                radioButton=findViewById(id);

                if(radioButton.getText().toString().equals("2016")) {
                    Snackbar.make(v, "Right answer", Snackbar.LENGTH_LONG).show();
                    //Snackbar.make(v, "Right answer"+count, Snackbar.LENGTH_LONG).show();
                    count++;

                }
                else {
                    Snackbar.make(v,"Incorect",Snackbar.LENGTH_LONG).show();
                }
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity2.this,MainActivity3.class);
                i.putExtra("count",count);
                startActivity(i);
            }
        });
    }
}