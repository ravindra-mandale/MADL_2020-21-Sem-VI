package edu.ritindia.calcapp.quiz2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity3 extends AppCompatActivity {
    RadioButton radioButton;
    RadioGroup radioGroup;
    FloatingActionButton floatingActionButton;
    Button button,mark;
    Intent I1;
    int count;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        floatingActionButton=findViewById(R.id.floatingActionButton3);
        radioGroup=findViewById(R.id.radiogroup3);
        mark=findViewById(R.id.marks);
        button=findViewById(R.id.button3);
        I1=getIntent();
        count=I1.getIntExtra("count",0);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id=radioGroup.getCheckedRadioButtonId();
                radioButton=findViewById(id);
                if(radioButton.getText().toString().equals("James Gosling")) {
                    count++;
                    Snackbar.make(v, "Right answer", Snackbar.LENGTH_LONG).show();
                }
                else {
                    Snackbar.make(v,"Incorect",Snackbar.LENGTH_LONG).show();
                }
            }
        });
        mark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Snackbar.make(v,"You Got "+count*100/3+" %",Snackbar.LENGTH_LONG).show();
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity3.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
}