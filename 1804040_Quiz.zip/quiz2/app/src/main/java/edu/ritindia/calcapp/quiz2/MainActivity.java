package edu.ritindia.calcapp.quiz2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    RadioButton radioButton;
    RadioGroup radioGroup;
    FloatingActionButton floatingActionButton;
    Button button;
    int count=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        floatingActionButton=findViewById(R.id.floatingActionButton);
        radioGroup=findViewById(R.id.radiogroup1);
        button=findViewById(R.id.button);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id=radioGroup.getCheckedRadioButtonId();
                radioButton=findViewById(id);
                if(radioButton.getText().toString().equals("Narendra Modi")) {
                    Snackbar.make(v, "Right answer", Snackbar.LENGTH_LONG).show();
                     count++;
                }
                else {
                    Snackbar.make(v,"Incorect",Snackbar.LENGTH_LONG).show();
                }
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i=new Intent(MainActivity.this,MainActivity2.class);
                i.putExtra("count",count);
                startActivity(i);
            }
        });
    }
}