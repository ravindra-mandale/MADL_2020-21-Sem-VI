package edu.ritindia.prathmeshb.shared_1704038;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText Name,Password;
    Button btn_save,btn_display,btn_clear;
    SharedPreferences sp;
    SharedPreferences.Editor editor;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sp=getSharedPreferences("RIT",MODE_PRIVATE);
        editor=sp.edit();

        btn_save=findViewById(R.id.button);
        btn_display=findViewById(R.id.button2);
        btn_clear=findViewById(R.id.button3);
        Name=findViewById(R.id.editText);
        Password=findViewById(R.id.editText2_ps);



        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nm=Name.getText().toString();  //insert operation
                String pass=Password.getText().toString();
                editor.putString("Userid",nm);
                editor.putString("Password",pass);

                editor.commit();//to save changes //method of edit class
            }
        });
        btn_clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Name.setText("");
                Password.setText("");
            }
        });
        btn_display.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1=null,s2=null;
                if(sp.contains("Userid"))   //for searching key
                {
                    s1=   sp.getString("Userid",null);

                }
                if(sp.contains("Password"))   //for searching key
                {
                    s2=   sp.getString("Password",null);
                }
                Name.setText(s1);
                Password.setText(s2);//editor,clear to clear all

            }
        });



    }
}
