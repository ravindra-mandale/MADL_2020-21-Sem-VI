package edu.ritindia.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button button1,button2,button3,button4;
    EditText edt1,edt2;
    int a,b,ans;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1=findViewById(R.id.btn1);
        button2=findViewById(R.id.btn2);
        button3=findViewById(R.id.btn3);
        button4=findViewById(R.id.btn4);

        edt1=findViewById(R.id.et1);
        edt2=findViewById(R.id.et2);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a=Integer.parseInt(edt1.getText().toString());
                b=Integer.parseInt(edt2.getText().toString());
                ans=a+b;
                Toast.makeText(getApplicationContext(),"Addition is "+ans,Toast.LENGTH_LONG).show();

            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a=Integer.parseInt(edt1.getText().toString());
                b=Integer.parseInt(edt2.getText().toString());
                ans=a-b;
                Toast.makeText(getApplicationContext(),"Subtraction is "+ans,Toast.LENGTH_LONG).show();
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a = Integer.parseInt(edt1.getText().toString());
                b = Integer.parseInt(edt2.getText().toString());
                ans = a * b;
                Toast.makeText(getApplicationContext(), "Multiplication is " + ans, Toast.LENGTH_LONG).show();

            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a = Integer.parseInt(edt1.getText().toString());
                b = Integer.parseInt(edt2.getText().toString());
                ans = a / b;
                Toast.makeText(getApplicationContext(), "Division " + ans, Toast.LENGTH_LONG).show();

            }
        });






    }
}