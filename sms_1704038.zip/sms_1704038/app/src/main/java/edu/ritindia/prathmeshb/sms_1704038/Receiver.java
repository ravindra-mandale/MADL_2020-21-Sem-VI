package edu.ritindia.prathmeshb.sms_1704038;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.widget.Toast;

public class Receiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("android.provider.Telephony.SMS_RECEIVED")) {

            SmsMessage[] msgs = new SmsMessage[0];
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
                msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent);
            }
            for (SmsMessage sms : msgs) {
                String message = sms.getMessageBody();
                String number = sms.getOriginatingAddress();
                Toast.makeText(context, "Message :" + message, Toast.LENGTH_SHORT).show();
                Toast.makeText(context, "Number :" + number, Toast.LENGTH_SHORT).show();
            }
        }
    }
}
