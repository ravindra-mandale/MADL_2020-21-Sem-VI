package edu.ritindia.prathmeshb.sms_1704038;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode== REQUEST_SMS)
        {
            if(grantResults.length>0 && grantResults[0]== PackageManager.PERMISSION_GRANTED)
            {
                sendSMS();
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Permission rejected",Toast.LENGTH_LONG).show();
            }
        }

    }

    private  final  static int REQUEST_SMS=2;
    Button btnSMS,btnReceiveSMS;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSMS=findViewById(R.id.button3);
        btnReceiveSMS=findViewById(R.id.button4);

        btnSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendSMS();
            }
        });

        btnReceiveSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                receiveSMS();
            }
        });
    }

    private  void sendSMS()

    {

        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_SMS);
        } else {
            SmsManager smsManager = SmsManager.getDefault();
            //SmsManager smsManager= SmsManager.getDefault();
            smsManager.sendTextMessage("+7775971704", "+7775971704", "Hi Prathmesh, this is demo message", null, null);
        }
    }

    private  void receiveSMS()
    {

        if(ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECEIVE_SMS)!= PackageManager.PERMISSION_GRANTED)
        {
            Toast.makeText(getApplicationContext(),"message is   not  sent",Toast.LENGTH_LONG).show();

            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.RECEIVE_SMS},REQUEST_SMS);
        }
        else
        {
            SmsManager smsManager=SmsManager.getDefault();
            //SmsManager smsManager= SmsManager.getDefault();
            Toast.makeText(getApplicationContext(),"message is sent",Toast.LENGTH_LONG).show();
            smsManager.sendTextMessage("+7775971704","+7775971704","Hi Prathmesh, This is demo message",null,null);
        }
    }

}
