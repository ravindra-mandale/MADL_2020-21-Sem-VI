package com.example.akash.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    TextView edit1,edit2;
    Button login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edit1 = findViewById(R.id.ed1);
        edit2 = findViewById(R.id.ed2);
        login = findViewById(R.id.button);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = edit1.getText().toString();
                String roll = edit2.getText().toString();

                Intent i = new Intent(getApplicationContext(), MainActivity2.class);
                Bundle bundle=new Bundle();
                bundle.putString("key1",name);
                bundle.putString("key2",roll);
                i.putExtras(bundle);
                startActivity(i);

            }
        });
    }
}