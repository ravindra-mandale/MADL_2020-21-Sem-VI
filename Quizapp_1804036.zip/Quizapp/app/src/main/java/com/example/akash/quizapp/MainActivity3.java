package com.example.akash.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity3 extends AppCompatActivity {

    Button submit,exit;
    RadioGroup rg3;
    RadioButton rb3,radioBtn1,radiobtn2,radiobtn3,radiobtn4;
    int count;
    TextView n,r,marks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        submit=findViewById(R.id.button2);
        exit=findViewById(R.id.button3);
        rg3=findViewById(R.id.radiogroup3);
        n=findViewById(R.id.textView5);
        r=findViewById(R.id.textView7);
        radioBtn1=findViewById(R.id.radioButton9);
        radiobtn2=findViewById(R.id.radioButton10);
        radiobtn3=findViewById(R.id.radioButton7);
        radiobtn4=findViewById(R.id.radioButton8);

        Bundle b2=getIntent().getExtras();
        String name=b2.getString("key3","akash");
        String roll=b2.getString("key4","00");
        count=b2.getInt("key5",0);

        n.setText(name);
        r.setText(roll);

        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(i);
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int id3=rg3.getCheckedRadioButtonId();
                rb3=findViewById(id3);

                switch (id3)
                {
                    case R.id.radioButton7:
                        count=count+1;
                        radiobtn3.setTextColor(Color.GREEN);
                        Toast.makeText(getApplicationContext(), rb3.getText().toString(), Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton8:
                        radiobtn4.setTextColor(Color.RED);
                        Toast.makeText(getApplicationContext(), rb3.getText().toString(), Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton9:
                        radioBtn1.setTextColor(Color.RED);
                        Toast.makeText(getApplicationContext(), rb3.getText().toString(), Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton10:
                        radiobtn2.setTextColor(Color.RED);
                        Toast.makeText(getApplicationContext(), rb3.getText().toString(), Toast.LENGTH_LONG).show();
                        break;
                }
                
                radiobtn3.setTextColor(Color.GREEN);
                Snackbar.make(v,"Total Marks:"+count,Snackbar.LENGTH_LONG).show();

            }
        });

    }
}