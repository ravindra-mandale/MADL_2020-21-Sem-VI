package com.example.akash.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    Button next;
    RadioGroup rg,rg2;
    RadioButton rb,rb2,radioBtn1,radioBtn2;
    int count=0;
    TextView n,r;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        next=findViewById(R.id.btn);
        rg=findViewById(R.id.radioGroup1);
        rg2=findViewById(R.id.radiogroup2);
        n=findViewById(R.id.textView6);
        r=findViewById(R.id.textView4);
        radioBtn1=findViewById(R.id.radioButton3);
        radioBtn2=findViewById(R.id.radioButton5);

        Bundle b1=getIntent().getExtras();
        String roll=b1.getString("key2","00");
        String name=b1.getString("key1","akash");

        n.setText(name);
        r.setText(roll);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int id=rg.getCheckedRadioButtonId();
                rb=findViewById(id);

                switch (id)
                {
                    case R.id.radioButton1:
                        Toast.makeText(getApplicationContext(),rb.getText().toString(),Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton2:
                        Toast.makeText(getApplicationContext(),rb.getText().toString(),Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton3:
                        count=count+1;
                        radioBtn1.setTextColor(Color.GREEN);
                        Toast.makeText(getApplicationContext(),rb.getText().toString(),Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton4:
                        Toast.makeText(getApplicationContext(),rb.getText().toString(),Toast.LENGTH_LONG).show();
                        break;
                }

                int id2=rg2.getCheckedRadioButtonId();
                rb2=findViewById(id2);

                switch (id2)
                {
                    case R.id.radioButton5:
                        count=count+1;
                        radioBtn2.setTextColor(Color.GREEN);
                        Toast.makeText(getApplicationContext(), rb2.getText().toString(), Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton6:
                        Toast.makeText(getApplicationContext(), rb2.getText().toString(), Toast.LENGTH_LONG).show();
                        break;
                }

                Intent i2= new Intent(getApplicationContext(),MainActivity3.class);
                Bundle b=new Bundle();
                b.putString("key3",name);
                b.putString("key4",roll);
                b.putInt("key5",count);
                i2.putExtras(b);
                startActivity(i2);
            }
        });
    }
}