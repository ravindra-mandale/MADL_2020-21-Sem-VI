package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import static com.google.android.material.snackbar.BaseTransientBottomBar.LENGTH_LONG;


public class MainActivity2 extends AppCompatActivity {
    RadioGroup rg;
    RadioButton rb;
    FloatingActionButton b1;
    Button btn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        rg=findViewById(R.id.radioGroup);
        b1=findViewById(R.id.floatingActionButton);
        btn2=findViewById(R.id.button2);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id=rg.getCheckedRadioButtonId();
                rb=findViewById(id);
                switch (id)
                {
                    case R.id.radioButton5:
                        Snackbar.make(v,"Answer is wrong try again", LENGTH_LONG).show();
                        break;

                    case R.id.radioButton6:
                        Snackbar.make(v,"Answer is wrong try again", LENGTH_LONG).show();
                        break;

                    case R.id.radioButton7:
                        Snackbar.make(v,"Answer is right", LENGTH_LONG).show();
                        break;

                    case R.id.radioButton8:
                        Snackbar.make(v,"Answer is wrong try again", LENGTH_LONG).show();
                        break;

                }


            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2=new Intent(MainActivity2.this, MainActivity3.class);
                startActivity(intent2);
            }
        });
    }
}