package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import static com.google.android.material.snackbar.BaseTransientBottomBar.LENGTH_LONG;
import static com.google.android.material.snackbar.Snackbar.make;

public class MainActivity3 extends AppCompatActivity {
    RadioGroup rg;
    RadioButton rb;
    FloatingActionButton b1;
    Button btn3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        rg=findViewById(R.id.radiogroup1);
        b1=findViewById(R.id.floatingActionButton2);
        btn3=findViewById(R.id.button4);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id=rg.getCheckedRadioButtonId();
                rb=findViewById(id);
                switch (id)
                {
                    case R.id.radioButton10:
                        Snackbar.make(v,"Answer is wrong try again", LENGTH_LONG).show();
                        break;

                    case R.id.radioButton11:
                        Snackbar.make(v,"Answer is wrong try again", LENGTH_LONG).show();
                        break;

                    case R.id.radioButton12:
                        Snackbar.make(v,"Answer is wrong try again", LENGTH_LONG).show();
                        break;

                    case R.id.radioButton13:
                        Snackbar.make(v,"Answer is right", LENGTH_LONG).show();
                        break;

                }


            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3=new Intent(MainActivity3.this,MainActivity.class);
                startActivity(intent3);
            }
        });
    }
}