package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;


import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import static com.google.android.material.snackbar.Snackbar.*;

public class MainActivity extends AppCompatActivity {
    RadioGroup rg;
    RadioButton rb;
    FloatingActionButton b1;
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rg=findViewById(R.id.r1);
        b1=findViewById(R.id.button);
        btn1=findViewById(R.id.button3);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id=rg.getCheckedRadioButtonId();
                rb=findViewById(id);
                switch (id)
                {
                    case R.id.radioButton:
                        Snackbar.make(v,"Answer is wrong try again", LENGTH_LONG).show();
                        break;

                    case R.id.radioButton2:
                        Snackbar.make(v,"Answer is wrong try again", LENGTH_LONG).show();
                        break;

                    case R.id.radioButton3:
                        Snackbar.make(v,"Answer is wrong try again", LENGTH_LONG).show();
                        break;

                    case R.id.radioButton4:
                        Snackbar.make(v,"Answer is right", LENGTH_LONG).show();
                        break;

                }


            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(MainActivity.this,MainActivity2.class);
                startActivity(intent1);
            }
        });
    }
}