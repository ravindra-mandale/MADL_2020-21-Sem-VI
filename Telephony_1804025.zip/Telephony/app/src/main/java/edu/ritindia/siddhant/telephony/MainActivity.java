package edu.ritindia.siddhant.telephony;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button b1;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.getinfo);
        textView = findViewById(R.id.textView);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                StringBuilder sb=new StringBuilder();



                TelephonyManager tm=(TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
                int callstate = tm.getCallState();
                String callstat="";

                switch (callstate)
                {

                    case TelephonyManager.CALL_STATE_IDLE:
                        callstat="Call State:Phone is Idle\n";
                        break;


                    case TelephonyManager.CALL_STATE_OFFHOOK:
                        callstat="Call State: Phone is in use\n";
                        break;


                    case TelephonyManager.CALL_STATE_RINGING:
                        callstat="Call State: Phone is Ringing\n";
                        break;


                }

                String opname="Operator ID: "+ tm.getNetworkOperator();
                opname=opname+"\n Operator Name:"+tm.getNetworkOperatorName();

                int phonetype=tm.getPhoneType();
                String ptype="";

                switch (phonetype)
                {

                    case TelephonyManager.PHONE_TYPE_CDMA:
                        ptype="\nPhone Type: CDMA\n";
                        break;

                    case TelephonyManager.PHONE_TYPE_GSM:
                        ptype="Phone Type: GSM\n";
                        break;


                    case TelephonyManager.PHONE_TYPE_SIP:
                        ptype="Phone Type: SIP\n";
                        break;


                    case TelephonyManager.PHONE_TYPE_NONE:
                        ptype="Phone Type: None\n";
                        break;



                }


                boolean isRoaming=tm.isNetworkRoaming();
                String pDetails="";
                if(isRoaming)
                {

                    pDetails="Roaming: Yes\n";
                }
                else
                {
                    pDetails="Roaming: No\n";
                }

                int sim=tm.getSimState();
                String sstate="";

                switch (sim)
                {

                    case TelephonyManager.SIM_STATE_ABSENT:
                        sstate="Sim State: Absent\n";
                        break;

                    case TelephonyManager.SIM_STATE_NETWORK_LOCKED:
                        sstate="Sim State: Network Locked\n";
                        break;


                    case TelephonyManager.SIM_STATE_PIN_REQUIRED:
                        sstate="Sim State: Pin Required\n";
                        break;

                    case TelephonyManager.SIM_STATE_READY:
                        sstate="Sim State: Ready\n";
                        break;

                    case TelephonyManager.SIM_STATE_UNKNOWN:
                        sstate="Sim State: Unknown\n";
                        break;

                }
                sb.append(callstat);
                sb.append(opname) ;
                sb.append(ptype);
                sb.append(pDetails);
                sb.append(sstate);

                textView.setText(sb);

            }
        });
    }
}