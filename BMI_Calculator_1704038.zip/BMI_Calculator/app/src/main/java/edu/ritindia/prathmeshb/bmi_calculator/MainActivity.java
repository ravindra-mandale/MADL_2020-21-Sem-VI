package edu.ritindia.prathmeshb.bmi_calculator;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int num1,num2;
    EditText t1,t2;
    TextView t3,bmi;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t1 = findViewById(R.id.height);
        t2 = findViewById(R.id.weight);
        t3 = findViewById(R.id.result);
        b1 = findViewById(R.id.btn);
        bmi=findViewById(bmi);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num1 = Integer.parseInt(t1.getText().toString());
                num2 = Integer.parseInt(t2.getText().toString());
                float num =(float)(num1*num1)/10000;
                float result =  (float)(num2)/num;
                t3.setText(result+" ");
                if(result<=18.5)
                {
                    bmi.setText("Underweight");
                }

                else if (result>18.5&&result<=24.9)
                {
                    bmi.setText("Normal BMI");
                }
                else if(result>24.9)
                {
                    bmi.setText("Obese");
                }
            }
        });


    }
}
