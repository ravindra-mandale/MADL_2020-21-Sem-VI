package com.exp3.tenyears;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

public class Faculty extends AppCompatActivity {

    ImageView imageViewfa;
    ImageButton imageButtonfa;
    Button buttonfa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty);

        imageViewfa=findViewById(R.id.imageView3);
        imageButtonfa=findViewById(R.id.imageButtonfa);
        buttonfa=findViewById(R.id.buttonfa);

        imageButtonfa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                imageViewfa.setImageResource(R.drawable.nature1);
            }
        });

        buttonfa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i=new Intent(Faculty.this, MainActivity.class);
                startActivity(i);
            }
        });


    }
}