package student.rit.shidhanath.myapplication5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class page2 extends AppCompatActivity {

    RadioGroup radioGroup1,radioGroup2;
   // RadioButton a1,b1;
    RadioButton r1,r2,r3,r4,r5,r6,r7,r8;
    Button button1,button2;
    int count,x,y;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);
        intent=getIntent();
        count=intent.getIntExtra("marks",0);

        radioGroup1=findViewById(R.id.q3);
        radioGroup2=findViewById(R.id.q4);
        button1=findViewById(R.id.next2);
        button2=findViewById(R.id.back1);


        count=intent.getIntExtra("marks",0);


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               int a= radioGroup1.getCheckedRadioButtonId();
             //  a1=findViewById(a);
               if(R.id.d3==a)
               {
                    count=count+1;
               }


                int b= radioGroup2.getCheckedRadioButtonId();
             //   b1=findViewById(a);
                if(R.id.a4==b)
                {
                    count=count+1;

                }

             //   Toast.makeText(getApplicationContext(),"c = "+count,Toast.LENGTH_LONG).show();
                Intent i=new Intent(getApplicationContext(),page3.class);
                i.putExtra("marks",count);
                startActivity(i);

            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
                finish();
            }
        });



    }
}