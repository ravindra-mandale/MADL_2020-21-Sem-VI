package student.rit.shidhanath.myapplication5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

   RadioButton a1,b1,ans1,ans2;
   RadioButton r1,r2,r3,r4,r5,r6,r7,r8;
   RadioGroup radioGroup1,radioGroup2;
   Button button;
    int count=0,x,y;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        radioGroup1=findViewById(R.id.q1);
        radioGroup2=findViewById(R.id.q2);
        button=findViewById(R.id.next1);
        ans1=findViewById(R.id.a1);
        ans2=findViewById(R.id.d2);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int a=radioGroup1.getCheckedRadioButtonId();
                a1=findViewById(a);

                if(R.id.a1==a)
                {
                     count=count+1;

                }
                else {
                    a1.setTextColor(Color.RED);
                }
                ans1.setTextColor(Color.GREEN);

                int b=radioGroup2.getCheckedRadioButtonId();
                b1=findViewById(b);
                if(R.id.d2==b)
                {
                     count=count+1;
                }
                else {
                    b1.setTextColor(Color.RED);
                }
                ans2.setTextColor(Color.GREEN);
               // Toast.makeText(getApplicationContext(),"c = "+count,Toast.LENGTH_LONG).show();
                Intent intent=new Intent(getApplicationContext(),page2.class);
                intent.putExtra("marks",count);
                startActivity(intent);

            }
        });

    }
}