package student.rit.shidhanath.myapplication5;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class page3 extends AppCompatActivity {

      RadioButton r1,r2,r3,r4;
      Button button2;
      FloatingActionButton floatingActionButton;
      RadioGroup radioGroup;
      int count;
      Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page3);
        intent=getIntent();
        count=intent.getIntExtra("marks",0);

//        r1=findViewById(R.id.a5);
//        r2=findViewById(R.id.b5);
//        r3=findViewById(R.id.c5);
//        r4=findViewById(R.id.d5);
        radioGroup=findViewById(R.id.q5);
        button2=findViewById(R.id.back2);
        floatingActionButton=findViewById(R.id.submit);

        floatingActionButton .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a=radioGroup.getCheckedRadioButtonId();
                if(R.id.a5==a)
                {
                    count=count+1;
                }

                Snackbar.make(v,"Your score is "+count,Snackbar.LENGTH_LONG).setAction("Home", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }).show();
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
                finish();
            }
        });





    }
}