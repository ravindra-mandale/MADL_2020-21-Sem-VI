package edu.ritindia.siddhant.quiz_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class que3 extends AppCompatActivity {

    RadioGroup rg;
    RadioButton rb1;
    FloatingActionButton fa;
    Button bt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_que3);
        rg = findViewById(R.id.radioGroup3);
        //rb1 = findViewById(R.id.radioButton);

        fa = findViewById(R.id.floatingActionButton);
        fa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int i=0;
                int select = rg.getCheckedRadioButtonId();
                rb1 = findViewById(select);
                Intent intent=getIntent();
                String count=intent.getStringExtra("key");
                if(rg.getCheckedRadioButtonId()!=-1)
                {
                    if(rb1.getText().toString().equals("Stored"))
                    {
                        i = Integer.parseInt(count)+1;

                    }
                    else
                    {
                        i= Integer.parseInt(count);
                    }
                    Snackbar.make(v,"Result: "+i,Snackbar.LENGTH_LONG).setAction("Finish", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent i4 = new Intent(que3.this, MainActivity.class);
                            startActivity(i4);
                            finish();
                        }
                    }).show();
                    //Toast.makeText(getApplicationContext(),""+i,Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Snackbar.make(v,"Result: "+count,Snackbar.LENGTH_LONG).setAction("Finish", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent i4 = new Intent(que3.this, MainActivity.class);
                            startActivity(i4);
                            finish();
                        }
                    }).show();
                    //Toast.makeText(getApplicationContext(),""+count,Toast.LENGTH_SHORT).show();
                }
            }
        });
        bt=findViewById(R.id.bt);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i5 = new Intent(que3.this, que2.class);
                startActivity(i5);
                finish();
            }
        });
    }
}