package edu.ritindia.siddhant.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button add, sub, mul, div;
    EditText num1, num2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        add=findViewById(R.id.button);
        sub=findViewById(R.id.button2);
        mul=findViewById(R.id.button3);
        div=findViewById(R.id.button4);

        num1=findViewById(R.id.editTextNumber);
        num2=findViewById(R.id.editTextNumber2);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str1, str2;
                str1= num1.getText().toString();
                str2= num2.getText().toString();



                if(str1.isEmpty())
                {
                   num1.setError("Please Enter Valid Number");
                    return;
                }
                if(str2.isEmpty())
                {
                    num2.setError("Please Enter Valid Number");
                    return;
                }

                int a = Integer.parseInt(str1);
                int b = Integer.parseInt(str2);
                int Result = a + b;
                String sol=Integer.toString(Result);
                Toast.makeText(getApplicationContext(), sol, Toast.LENGTH_LONG).show();

            }
        });

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str1, str2;
                str1= num1.getText().toString();
                str2= num2.getText().toString();
                int a = Integer.parseInt(str1);
                int b = Integer.parseInt(str2);

                if(str1.isEmpty())
                {
                    num1.setError("Please Enter Valid Number");
                    return;
                }
                if(str2.isEmpty())
                {
                    num2.setError("Please Enter Valid Number");
                    return;
                }
                int Result = a - b;
                String sol=Integer.toString(Result);
                Toast.makeText(getApplicationContext(), sol, Toast.LENGTH_LONG).show();

            }
        });

        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str1, str2;
                str1= num1.getText().toString();
                str2= num2.getText().toString();
                int a = Integer.parseInt(str1);
                int b = Integer.parseInt(str2);

                if(str1.isEmpty())
                {
                    num1.setError("Please Enter Valid Number");
                    return;
                }
                if(str2.isEmpty())
                {
                    num2.setError("Please Enter Valid Number");
                    return;
                }
                int Result = a * b;
                String sol=Integer.toString(Result);
                Toast.makeText(getApplicationContext(), sol, Toast.LENGTH_LONG).show();

            }
        });

        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str1, str2;
                str1= num1.getText().toString();
                str2= num2.getText().toString();
                int a = Integer.parseInt(str1);
                int b = Integer.parseInt(str2);

                if(str1.isEmpty())
                {
                    num1.setError("Please Enter Valid Number");
                    return;
                }
                if(str2.isEmpty())
                {
                    num2.setError("Please Enter Valid Number");
                    return;
                }
                int Result = a / b;
                String sol=Integer.toString(Result);
                Toast.makeText(getApplicationContext(), sol, Toast.LENGTH_LONG).show();

            }
        });
    }
}