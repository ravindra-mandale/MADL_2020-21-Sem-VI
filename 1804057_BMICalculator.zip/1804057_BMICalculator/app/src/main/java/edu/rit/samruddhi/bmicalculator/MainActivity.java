package edu.rit.samruddhi.bmicalculator;



import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText editTextNumber1,editTextNumber2;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        button=findViewById(R.id.button);
        editTextNumber1=findViewById(R.id.editTextNumber1);
        editTextNumber2=findViewById(R.id.editTextNumber2);

        button.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        double num1,num2,c,d;
        int id=v.getId();
        if(id==R.id.button)
        {
            num1=Integer.parseInt(editTextNumber1.getText().toString());
            num2=Integer.parseInt(editTextNumber2.getText().toString());
            d=num2*num2*0.0001;
            c=num1/d;
            Toast.makeText(getApplicationContext(),"Your BMI Result   "+c,Toast.LENGTH_LONG).show();

        }





    }
}