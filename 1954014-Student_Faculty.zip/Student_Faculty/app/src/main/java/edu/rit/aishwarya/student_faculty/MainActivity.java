package edu.rit.aishwarya.student_faculty;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Spinner spinner;
        Button login,cancel;
        EditText username,password;
        username=findViewById(R.id.Username);
        password=findViewById(R.id.Pass);
        login=findViewById(R.id.b1);
        spinner=findViewById(R.id.sp);
        cancel=findViewById(R.id.b2);
        ArrayAdapter<CharSequence> arrayAdapter=ArrayAdapter.createFromResource(this,R.array.designation,android.R.layout.simple_spinner_item);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(arrayAdapter);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (spinner.getSelectedItem().toString().equals("Faculty"))
                {
                    if ((username.getText().toString().equals("mahi")) && (password.getText().toString().equals("mahi")))
                    {
                        Intent i = new Intent(MainActivity.this, Student_Faculty1.class);
                        startActivity(i);
                    }
                    else
                        {
                        Toast.makeText(getApplicationContext(), "Wrong username or password", Toast.LENGTH_LONG).show();
                        }
                }
                else if (spinner.getSelectedItem().toString().equals("Student") )
                {
                    if ((username.getText().toString().equals("virat")) && (password.getText().toString().equals("virat")))
                    {
                        Intent i = new Intent(MainActivity.this, Student_Faculty2.class);
                        startActivity(i);
                    }
                    else
                        {
                        Toast.makeText(getApplicationContext(), "Wrong username or password", Toast.LENGTH_LONG).show();

                    }
                }
                else if(spinner.getSelectedItem().toString().equals("Lab Assistant"))
                {
                    if ((username.getText().toString().equals("rohit")) && (password.getText().toString().equals("rohit")))
                    {
                        Intent i = new Intent(MainActivity.this, Student_Faculty3.class);
                        startActivity(i);

                    } else {
                        Toast.makeText(getApplicationContext(), "Wrong username or password", Toast.LENGTH_LONG).show();

                    }
                }
                else{
                    Toast.makeText(getApplicationContext(), "choose any option", Toast.LENGTH_LONG).show();

                }


            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();

            }
        });

    }
}