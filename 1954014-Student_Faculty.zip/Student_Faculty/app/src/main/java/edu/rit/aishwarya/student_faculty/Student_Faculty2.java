package edu.rit.aishwarya.student_faculty;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Student_Faculty2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student__faculty2);

        Button logout,bt;
        ImageView iv;
        logout = findViewById(R.id.b6);
        iv=findViewById(R.id.imageView);
        bt=findViewById(R.id.b5);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Student_Faculty2.this, MainActivity.class);
                startActivity(i);
            }

        });
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv.setImageResource(R.drawable.kohli);
            }
        });

    }
}