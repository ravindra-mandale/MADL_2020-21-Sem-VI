package com.example.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static android.app.ProgressDialog.show;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText editTextText1, editTextText2;
    Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextText1 = findViewById(R.id.editTextText1);
        editTextText2 = findViewById(R.id.editTextText2);
        button.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int num1, num2;
        double c, d;
        int id = v.getId();
        if (id == R.id.button) {
            num1 = Integer.parseInt(editTextText1.getText().toString());
            num2 = Integer.parseInt(editTextText2.getText().toString());
            d = num2 * num2 * 0.0001;
            c = num1 / d;

            int text;
            Toast.makeText(getApplicationContext(), "Your BMI Result " + c, Toast.LENGTH_LONG).show();


        }

    }
}