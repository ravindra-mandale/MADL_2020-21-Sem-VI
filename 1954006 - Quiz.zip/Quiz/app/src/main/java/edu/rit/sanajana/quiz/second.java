package edu.rit.sanajana.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;

public class second extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        Intent i=getIntent();
        int a=i.getIntExtra("result1",0);
        RadioGroup rg;
        Button b1;
        rg=findViewById(R.id.radiogroup2);
        b1=findViewById(R.id.button2);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int ans2=rg.getCheckedRadioButtonId();
                Intent i=new Intent(second.this,third.class);
                i.putExtra("result1",a);
                i.putExtra("result2",ans2);
                startActivity(i);
            }
        });
    }
}