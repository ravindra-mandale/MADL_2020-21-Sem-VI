package edu.rit.sanajana.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RadioGroup rg;
        Button b1;
        rg=findViewById(R.id.radiogroup1);
        b1=findViewById(R.id.button1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int ans1=rg.getCheckedRadioButtonId();
                Intent i=new Intent(MainActivity.this,second.class);
                i.putExtra("result1",ans1);
                startActivity(i);
            }
        });
    }
}