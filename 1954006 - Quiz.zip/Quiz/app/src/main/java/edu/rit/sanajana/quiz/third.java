package edu.rit.sanajana.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class third extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        Intent i=getIntent();
        int a=i.getIntExtra("result1",0);
        int b=i.getIntExtra("result2",0);
        RadioGroup rg;
        FloatingActionButton submit;
        rg=findViewById(R.id.radiogroup3);
        submit=findViewById(R.id.floatingbutton);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int result=0;
                int ans3=rg.getCheckedRadioButtonId();
                if(a==(R.id.radioButton4))
                {
                    result=result+10;
                }
                if(b==(R.id.radioButton8))
                {
                    result=result+10;
                }
                if(ans3==(R.id.radioButton9))
                {
                    result=result+10;
                }
                Toast.makeText(getApplicationContext(),"Score is :" +result,Toast.LENGTH_LONG).show();
            }
        });

    }
}