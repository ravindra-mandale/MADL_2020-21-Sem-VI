package student.rit.shidhanath.bmccalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView weightkg, heightcm;

    Button calculate;
    TextView res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        weightkg=findViewById(R.id.weightkg);
        heightcm=findViewById(R.id.heightcm);
        calculate=findViewById(R.id.calculate);
        res=findViewById(R.id.result);
        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float r,a,b;

                a=Float.parseFloat(weightkg.getText().toString());
                b=Float.parseFloat(heightcm.getText().toString());

                    b = b / 100;
                    r = a / (b * b);
                    Toast.makeText(getApplicationContext(), "Result :" + r, Toast.LENGTH_LONG).show();
                    res.setText("Result : " + r);
                }
        });





    }
}