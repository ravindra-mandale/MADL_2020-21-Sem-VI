package edu.ritindia.a1804029_exp7;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import static android.os.Build.VERSION_CODES.M;

public class MainActivity extends AppCompatActivity {
    Button button,btn2;
    TextView textView;
    EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button=findViewById(R.id.button);
        btn2=findViewById(R.id.button2);
        editText=findViewById(R.id.phon);
        textView=findViewById(R.id.textview);
        button.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = M)
            @Override
            public void onClick(View v) {

                TelephonyManager tm=(TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);

                //Calling the methods of TelephonyManager the returns the information
                //String IMEINumber=tm.getDeviceId();
                //String subscriberID=tm.getDeviceId();
                // String SIMSerialNumber=tm.getSimSerialNumber();
                String networkCountryISO=tm.getNetworkCountryIso();
                String SIMCountryISO=tm.getSimCountryIso();
                String softwareVersion=tm.getDeviceSoftwareVersion();
                String voiceMailNumber=tm.getVoiceMailNumber();

                //Get the phone type
                String strphoneType="";

                int phoneType=tm.getPhoneType();

                switch (phoneType)
                {
                    case (TelephonyManager.PHONE_TYPE_CDMA):
                        strphoneType="CDMA";
                        break;
                    case (TelephonyManager.PHONE_TYPE_GSM):
                        strphoneType="GSM";
                        break;
                    case (TelephonyManager.PHONE_TYPE_NONE):
                        strphoneType="NONE";
                        break;
                }

                //getting information if phone is in roaming
                boolean isRoaming=tm.isNetworkRoaming();

                String info="Phone Details:\n";
                // info+="\n IMEI Number:"+IMEINumber;
                // info+="\n SubscriberID:"+subscriberID;
                //info+="\n Sim Serial Number:"+SIMSerialNumber;
                info+="\n SIM Country ISO:"+SIMCountryISO;
                info+="\n Network Country ISO:"+networkCountryISO;
                info+="\n Software Version:"+softwareVersion;
                info+="\n Phone Network Type:"+strphoneType;
                info+="\n Voice Mail Number:"+voiceMailNumber;
                info+="\n In Roaming? :"+isRoaming;

                textView.setText(info);//displaying the information in the textView
            }

        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SmsManager smsManager= SmsManager.getDefault();
                smsManager.sendTextMessage(editText.getText().toString(),null,"hello",null,null);
            }
        });
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            Log.d("PLAYGROUND", "Permission is not granted, requesting");
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 123);
            button.setEnabled(false);
        } else {
            Log.d("PLAYGROUND", "Permission is granted");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 123) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("PLAYGROUND", "Permission has been granted");
                textView.setText("You can send SMS!");
                button.setEnabled(true);
            } else {
                Log.d("PLAYGROUND", "Permission has been denied or request cancelled");
                textView.setText("You can not send SMS!");
                button.setEnabled(false);
            }
        }
    }
}