package edu.ritindia.a1804029_exp7;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.widget.Toast;

public class smsReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle b=intent.getExtras();
        Object o[]=(Object[]) b.get("pdus");
        SmsMessage message = SmsMessage.createFromPdu((byte[]) o[0]);
        String sender=message.getOriginatingAddress();
        String msg=message.getMessageBody();
        //Toast.makeText(context,"sent you message", Toast.LENGTH_LONG).show();
        Toast.makeText(context,sender+"sent you message"+msg, Toast.LENGTH_LONG).show();
    }

}
