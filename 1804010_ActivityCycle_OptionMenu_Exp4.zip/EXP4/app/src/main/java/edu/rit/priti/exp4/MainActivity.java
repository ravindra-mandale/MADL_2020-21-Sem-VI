package edu.rit.priti.exp4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn;
    ImageView im;
    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        builder = new AlertDialog.Builder(this);
        Log.d("OnCreate", "Activity Created");

        im = findViewById(R.id.logo);
        btn = findViewById(R.id.RITbut);
        registerForContextMenu(btn);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.menu1:
                Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_LONG).show();
                im.setImageResource(R.drawable.clg);
                return true;
            case R.id.menu2:
                Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_LONG).show();
                im.setImageResource(R.drawable.lib);
                return true;
            case R.id.menu3:
                Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_LONG).show();
                im.setImageResource(R.drawable.hostel);
                return true;
            case R.id.menu4:
                builder.setMessage("Do you want to close this application ?")
                        .setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        finish();
                        Toast.makeText(getApplicationContext(), "Thank You",
                                Toast.LENGTH_SHORT).show();
                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        dialog.cancel();

                    }
                });

                AlertDialog alert = builder.create();

                alert.setTitle("Exit From Application");
                alert.show();

                return super.onContextItemSelected(item);
            default:
                return super.onOptionsItemSelected(item);

        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.contextmenu, menu);

    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.menu1:

                Intent i1 = new Intent(MainActivity.this, UG.class);
                startActivity(i1);
                return super.onContextItemSelected(item);
            case R.id.menu2:

                Intent i2 = new Intent(MainActivity.this, dipl.class);
                startActivity(i2);
                return super.onContextItemSelected(item);

            default:
                return super.onContextItemSelected(item);
        }
    }


    @Override
    protected void onStart() {
        super.onStart();
        Log.d("OnStart","Activity Started");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("onResume","Activity Resumed");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("onPause","Activity Paused");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("onStop","Activity Stopped");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("onDestroy","Activity Destroyed");
    }
}