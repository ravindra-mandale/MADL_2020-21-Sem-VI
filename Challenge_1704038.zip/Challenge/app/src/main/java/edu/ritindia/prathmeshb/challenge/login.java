package edu.ritindia.prathmeshb.challenge;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class login extends AppCompatActivity {

    Button b;
    EditText t1,t2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        b = findViewById(R.id.btn);
        t1 = findViewById(R.id.name);
        t2 = findViewById(R.id.pass);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(t1.getText().toString().equals("prathmesh"))
                {
                    if(t2.getText().toString().equals("attitude")) {
                        Intent i = new Intent(login.this, first.class);
                        startActivity(i);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),"wrong Password",Toast.LENGTH_LONG).show();
                    }
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"wrong Username",Toast.LENGTH_LONG).show();
                }

            }

        });

    }
}
