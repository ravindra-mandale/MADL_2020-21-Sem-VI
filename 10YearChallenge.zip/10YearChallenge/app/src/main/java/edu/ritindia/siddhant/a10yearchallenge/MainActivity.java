package edu.ritindia.siddhant.a10yearchallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText user,pass;
    Button login,cancel;
    Spinner a1;
    String Role []={"Faculty","Student","Lab_Assistant"};
    String rpost;
    ArrayAdapter<String> arrayAdapter;

    String Faculty_user ="teacher", Faculty_pass="123", Faculty_post="Faculty";
    String Student_user ="student", Student_pass="456", Student_post="Student";
    String LA_user ="LabA", LA_pass="789", LA_post="Lab_Assistant";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login=findViewById(R.id.button);
        cancel=findViewById(R.id.button2);
        user=findViewById(R.id.edit1);
        pass=findViewById(R.id.editPassword);
        a1=findViewById(R.id.spinner);


        arrayAdapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item,Role);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        a1.setAdapter(arrayAdapter);
        a1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                rpost = Role[position];

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });




        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str1, str2;
                str1 = user.getText().toString();
                str2 = pass.getText().toString();

                if (str1.isEmpty()) {
                    user.setError("Please Enter Valid Username");
                    return;
                }
                if (str2.isEmpty()) {
                    pass.setError("Please Enter Valid Password");
                    return;
                }
                if(str1.equals(Faculty_user) && str2.equals(Faculty_pass) && rpost.equals(Faculty_post)){
                    Intent i =new Intent(MainActivity.this, Faculty.class);
                    startActivity(i);
                    finish();

                }
                else if(str1.equals(Student_user) && str2.equals(Student_pass) && rpost.equals(Student_post)){
                    Intent i =new Intent(MainActivity.this, Student.class);
                    startActivity(i);
                    finish();
                }
                else if(str1.equals(LA_user) && str2.equals(LA_pass) && rpost.equals(LA_post)){
                    Intent i =new Intent(MainActivity.this, LabLabAssistant.class);
                    startActivity(i);
                    finish();
                }
                else{
                    Toast.makeText(getApplicationContext(),"You have wrong choice",Toast.LENGTH_LONG).show();
                }

            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                finish();
                //System.exit(0);
                    //moveTaskToBack(true);
                }

        });

    }
}