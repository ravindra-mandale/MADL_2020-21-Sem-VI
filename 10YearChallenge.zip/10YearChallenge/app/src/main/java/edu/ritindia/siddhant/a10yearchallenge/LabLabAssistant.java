package edu.ritindia.siddhant.a10yearchallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

public class LabLabAssistant extends AppCompatActivity {

    Button Logout2;
    ImageButton I1;
    ImageView LA;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab_assistent);

        Logout2=findViewById(R.id.button5);
        I1=findViewById(R.id.imageButton3);
        LA=findViewById(R.id.imageView3);
        I1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LA.setImageResource(R.drawable.l2);
            }
        });

                Logout2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(LabLabAssistant.this, MainActivity.class);
                        startActivity(i);
                        finish();
                    }
                });
    }
}