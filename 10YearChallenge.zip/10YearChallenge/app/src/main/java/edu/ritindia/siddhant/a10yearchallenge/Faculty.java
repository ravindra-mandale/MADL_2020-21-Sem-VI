package edu.ritindia.siddhant.a10yearchallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

public class Faculty extends AppCompatActivity {
    Button Logout;
    ImageView F;
    ImageButton I2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty);

        Logout=findViewById(R.id.button4);
        F=findViewById(R.id.imageView);
        I2=findViewById(R.id.imageButton);
        I2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                F.setImageResource(R.drawable.f2);
            }
        });
        Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =new Intent(Faculty.this, MainActivity.class);
                startActivity(i);
                finish();
            }
        });
    }
}