package edu.ritindia.siddhant.a10yearchallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

public class Student extends AppCompatActivity {
     Button Logout1;
     ImageButton I3;
     ImageView S;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        Logout1=findViewById(R.id.button3);
        I3=findViewById(R.id.imageButton2);
        S=findViewById(R.id.imageView2);
        I3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                S.setImageResource(R.drawable.s2);
            }
        });

        Logout1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =new Intent(Student.this, MainActivity.class);
                startActivity(i);
                finish();
            }
        });
    }
}