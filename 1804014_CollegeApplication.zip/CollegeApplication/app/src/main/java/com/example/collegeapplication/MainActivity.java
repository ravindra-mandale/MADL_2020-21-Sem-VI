package com.example.collegeapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    String designation[] = {"Student", "Faculty","Lab_Assitant"};
    Button login;
    EditText email, pass;
    ArrayAdapter <String> arrayAdapter;
    Spinner spinner;
    String retrived_post, retrived_name, retrived_pass;

    //By default teacher credentials
    String teacher_email = "teacher";
    String teacher_pass  = "1";
    String teacher_post  = "Faculty";

    //By default student Credentials
    String student_email = "student";
    String student_pass  = "2";
    String student_post  = "Student";

    //By default Lab Assitant credentials
    String Lab_assistant_email = "lab";
    String Lab_assistant_pass  = "3";
    String Lab_assistant_post  = "Lab_Assitant";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Get Id's

        login = findViewById(R.id.loginBtn);
        email = findViewById(R.id.username);
        pass = findViewById(R.id.password);

        //Spinner Id
        spinner = findViewById(R.id.spinner);

        //set arrayadapter
        arrayAdapter = new ArrayAdapter<String>(MainActivity.this , android.R.layout.simple_spinner_item, designation);

        //Set second dropdown activity
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        //Set Adapter
        spinner.setAdapter(arrayAdapter);

        //Event handling for spinner
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                //Retrive post from spinner
                retrived_post = designation[position];
                //Toast.makeText(MainActivity.this, retrived_name+ retrived_pass+retrived_post, Toast.LENGTH_LONG).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Retrived text
                retrived_name = email.getText().toString();
                retrived_pass = pass.getText().toString();

                //Toast.makeText(getApplicationContext(),retrived_name+ retrived_pass+retrived_post,Toast.LENGTH_LONG).show();

                //Comparison with credentials
                if(retrived_name.equals(student_email) && retrived_pass.equals(student_pass) && retrived_post.equals(student_post)){
                    startActivity(new Intent(getApplicationContext(), StudentDashboard.class));
                    finish();
                }
                else if(retrived_name.equals(teacher_email) && retrived_pass.equals(teacher_pass) && retrived_post.equals(teacher_post)){
                    startActivity(new Intent(getApplicationContext(), TeacherDashboard.class));
                    finish();
                }
                else if(retrived_name.equals(Lab_assistant_email) && retrived_pass.equals(Lab_assistant_pass) && retrived_post.equals(Lab_assistant_post)){
                    startActivity(new Intent(getApplicationContext(), LabAssistantDashboard.class));
                    finish();
                }
                else {
                    Toast.makeText(getApplicationContext(),"Your getting an error",Toast.LENGTH_LONG).show();
                }


            }
        });






    }
}