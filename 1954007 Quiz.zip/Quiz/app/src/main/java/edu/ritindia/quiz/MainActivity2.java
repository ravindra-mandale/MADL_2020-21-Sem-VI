package edu.ritindia.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent i=getIntent();
        int ans1=i.getIntExtra("Value1",0);
        RadioGroup rg;
        Button next;
        rg=findViewById(R.id.radiogroup2);
        next=findViewById(R.id.button2);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int ans2=rg.getCheckedRadioButtonId();
                Intent i=new Intent(MainActivity2.this,MainActivity3.class);
                i.putExtra("Value1",ans1);
                i.putExtra("Value2",ans2);
                startActivity(i);
            }
        });

    }
}