package edu.ritindia.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Intent i=getIntent();
        int ans1=i.getIntExtra("Value1",0);
        int ans2=i.getIntExtra("Value2",0);
        RadioGroup rg;
        FloatingActionButton submit;
        rg=findViewById(R.id.radiogroup3);
        submit=findViewById(R.id.floatingActionButton);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int result=0;
                int ans3=rg.getCheckedRadioButtonId();
                if(ans1==R.id.radioButton4)
                {
                    result=result+10;
                }
                if(ans2==R.id.radioButton5)
                {
                    result=result+10;
                }
                if(ans3==R.id.radioButton9)
                {
                    result=result+10;
                }
                Toast.makeText(getApplicationContext(),"Your score is:"+result,Toast.LENGTH_LONG).show();


            }
        });
    }
}