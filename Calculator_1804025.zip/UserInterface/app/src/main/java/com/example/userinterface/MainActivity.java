package com.example.userinterface;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button addition, subtraction, multiplicaton, division;
    EditText firstNum, secondNum;
    TextView solution;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addition = findViewById(R.id.add);
        subtraction = findViewById(R.id.sub);
        multiplicaton = findViewById(R.id.mul);
        division = findViewById(R.id.div);

        firstNum = findViewById(R.id.first);
        secondNum = findViewById(R.id.second);

        solution = findViewById(R.id.result);

        addition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String num1;
                String num2;

                num1 = firstNum.getText().toString();
                num2 = secondNum.getText().toString();

                if(num1.isEmpty()){
                    firstNum.setError("Please enter valid number");
                    return;
                }

                if(num2.isEmpty()){
                    secondNum.setError("Please enter valid number");
                    return;
                }

                int a = Integer.parseInt(num1);
                int b = Integer.parseInt(num2);

                String sol = Integer.toString(a+b);

                //Toast.makeText(getApplicationContext(),sol,Toast.LENGTH_LONG).show();

                solution.setText("Result : "+sol);
            }
        });


        subtraction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String num1;
                String num2;

                num1 = firstNum.getText().toString();
                num2 = secondNum.getText().toString();

                if(num1.isEmpty()){
                    firstNum.setError("Please enter valid number");
                    return;
                }

                if(num2.isEmpty()){
                    secondNum.setError("Please enter valid number");
                    return;
                }

                int a = Integer.parseInt(num1);
                int b = Integer.parseInt(num2);

                String sol = Integer.toString(a-b);

                //Toast.makeText(getApplicationContext(),sol,Toast.LENGTH_LONG).show();

                solution.setText("Result : "+sol);

            }
        });

        multiplicaton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String num1;
                String num2;

                num1 = firstNum.getText().toString();
                num2 = secondNum.getText().toString();

                if(num1.isEmpty()){
                    firstNum.setError("Please enter valid number");
                    return;
                }

                if(num2.isEmpty()){
                    secondNum.setError("Please enter valid number");
                    return;
                }

                int a = Integer.parseInt(num1);
                int b = Integer.parseInt(num2);

                String sol = Integer.toString(a*b);

                //Toast.makeText(getApplicationContext(),sol,Toast.LENGTH_LONG).show();

                solution.setText("Result : "+sol);
            }
        });

        division.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String num1;
                String num2;

                num1 = firstNum.getText().toString();
                num2 = secondNum.getText().toString();


                if(num1.isEmpty()){
                    firstNum.setError("Please enter valid number");
                    return;
                }

                if(num2.isEmpty()){
                    secondNum.setError("Please enter valid number");
                    return;
                }

                int a = Integer.parseInt(num1);
                int b = Integer.parseInt(num2);

                String sol = Integer.toString(a/b);

                //Toast.makeText(getApplicationContext(),sol,Toast.LENGTH_LONG).show();

                solution.setText("Result : "+sol);
            }
        });



    }
}