package com.example.akash.a10yearschallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    String[] role={"Student","Faculty","Lab Assistent"};
    String sname="Akash";
    String fname="AAA";
    String lname="MMM";
    Button cancel,login;
    EditText editText1,editText2;
    String user,pass,r;
    Spinner spinner;
    ArrayAdapter<String> arrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cancel=findViewById(R.id.btn1);
        login=findViewById(R.id.btn2);
        editText1=findViewById(R.id.et1);
        editText2=findViewById(R.id.et2);
        spinner=findViewById(R.id.spinner1);

        arrayAdapter=new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_spinner_item,role);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(arrayAdapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            r=spinner.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user = editText1.getText().toString();
                pass = editText2.getText().toString();

                if(user.isEmpty())
                {
                    editText1.setError("Enter valid user name.");
                    return;
                }
                if(pass.isEmpty())
                {
                    editText2.setError("Enter valid password.");
                    return;
                }

                if(sname.equals(user) && sname.equals(pass) && r.equals(role[0]))
                {
                    Intent i = new Intent(getApplicationContext(),student.class);
                    startActivity(i);
                    setContentView(R.layout.activity_student);
                }

                else if(fname.equals(user) && fname.equals(pass) && r.equals(role[1]))
                {
                    Intent i = new Intent(getApplicationContext(),faculty.class);
                    startActivity(i);
                    setContentView(R.layout.activity_faculty);
                }

                else if(user.equals(lname) && user.equals(lname) && r.equals(role[2]))
                {
                    Intent i = new Intent(getApplicationContext(),lab_assistant.class);
                    startActivity(i);
                    setContentView(R.layout.activity_lab_assistant);
                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText1.setText("");
                editText2.setText("");
            }
        });
    }
}