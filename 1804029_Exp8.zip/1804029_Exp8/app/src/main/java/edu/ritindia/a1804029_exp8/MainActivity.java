package edu.ritindia.a1804029_exp8;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText ed1,ed2,ed3,ed4;
    Button bt1,bt2,bt3;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sp = getSharedPreferences("Details",MODE_PRIVATE);
        ed1=findViewById(R.id.editTextTextPersonName);
        ed2=findViewById(R.id.editTextTextPersonName2);
        ed3=findViewById(R.id.editTextTextPersonName3);
        bt1=findViewById(R.id.button);
        bt2=findViewById(R.id.button2);
        bt3=findViewById(R.id.button3);
        if(sp.contains("Name"))
        {
            ed1.setText(sp.getString("Name",""));
        }
        if(sp.contains("MN"))
        {
            ed2.setText(sp.getString("MN",""));
        }
        if(sp.contains("AN"))
        {
            ed3.setText(sp.getString("AN",""));
        }

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=ed1.getText().toString();
                String mn=ed2.getText().toString();
                String an=ed3.getText().toString();


                SharedPreferences.Editor editor= sp.edit();
                editor.putString("Name",name);
                editor.putString("MN",mn);
                editor.putString("AN",an);

                editor.commit();
                Toast.makeText(getApplicationContext(),"Stored Succesfully",Toast.LENGTH_LONG).show();
            }
        });
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText("");
                ed2.setText("");
                ed3.setText("");


            }
        });
        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nm="",mon="",aan="",pan="";
                if(sp.contains("Name"))
                {
                    nm=sp.getString("Name","");

                }
                if(sp.contains("MN"))
                {
                    mon=sp.getString("MN","");

                }
                if(sp.contains("AN"))
                {
                    aan=sp.getString("AN","");

                }

                Toast.makeText(MainActivity.this,"name "+nm+"\nmobileno "+mon+"\nAadharno "+aan,Toast.LENGTH_LONG).show();
            }
        });
    }
}
