package edu.madlab.exp6.myapplication;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.BatteryManager;
import android.util.Log;
import android.widget.Toast;

public class BattaryReciever extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {



        String action=intent.getAction();
        if(action!=null && action.equals(BatteryManager.EXTRA_STATUS))
        {
          int status=intent.getIntExtra(BatteryManager.EXTRA_STATUS,-1);
          String msg="";
          switch (status)
          {

              case BatteryManager.BATTERY_STATUS_FULL:
                  msg="Full";
                  break;
              case BatteryManager.BATTERY_STATUS_CHARGING:
                  msg="Charging";
                  break;
              case BatteryManager.BATTERY_STATUS_DISCHARGING:
                  msg="Discharging";
                  break;
              case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                  msg="Not Charging";
                  break;
              case BatteryManager.BATTERY_STATUS_UNKNOWN:
                  msg="Unknown";
                  break;
          }
          Toast.makeText(context,msg,Toast.LENGTH_LONG).show();

          int level=intent.getIntExtra(BatteryManager.EXTRA_LEVEL,-1);
          int scale=intent.getIntExtra(BatteryManager.EXTRA_SCALE,-1);
          int percenage=(level*100)/scale;

          if(percenage<20)
          {
              Toast.makeText(context,"Battary Low",Toast.LENGTH_LONG).show();
          }

        }
    }
}
