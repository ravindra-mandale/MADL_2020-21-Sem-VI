package edu.ritindia.application;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class faculty2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty);
        Button after10yr,logout;
        ImageView img;
        logout=findViewById(R.id.button2);
        img=findViewById(R.id.imageView);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(faculty2.this,MainActivity.class);
                startActivity(i);
            }
        });
        after10yr=findViewById(R.id.button);
        after10yr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                img.setImageResource(R.drawable.faculty);

            }
        });



    }
}