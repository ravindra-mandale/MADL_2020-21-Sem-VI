package edu.ritindia.application;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Spinner spinner;
        Button btn,btn2;
        EditText e1,e2;

        spinner=findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> arrayAdapter=ArrayAdapter.createFromResource(this,R.array.designation, android.R.layout.simple_spinner_item);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(arrayAdapter);
        btn=findViewById(R.id.login);
        e1=findViewById(R.id.username);
        e2=findViewById(R.id.password);
        btn2=findViewById(R.id.cancel);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(spinner.getSelectedItem().toString().equals("faculty"))
                {
                    if ((e1.getText().toString().equals("faculty")) && (e2.getText().toString().equals("faculty"))) {
                        Intent i = new Intent(MainActivity.this, faculty2.class);
                        startActivity(i);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),"Wrong username or password",Toast.LENGTH_LONG).show();
                    }
                }
                   else if(spinner.getSelectedItem().toString().equals("student"))
                    {
                        if((e1.getText().toString().equals("student"))&&(e2.getText().toString().equals("student")))
                        {
                            Intent i= new Intent(MainActivity.this,Student.class);
                            startActivity(i);

                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),"Wrong username or password",Toast.LENGTH_LONG).show();
                        }

                    }
                   else
                    {
                        if((e1.getText().toString().equals("assistent"))&&(e2.getText().toString().equals("assistent")))
                        {
                            Intent i= new Intent(MainActivity.this,LabAssistant.class);
                            startActivity(i);

                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),"Wrong username or password",Toast.LENGTH_LONG).show();
                        }

                    }

            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               finish();

            }
        });





    }
}