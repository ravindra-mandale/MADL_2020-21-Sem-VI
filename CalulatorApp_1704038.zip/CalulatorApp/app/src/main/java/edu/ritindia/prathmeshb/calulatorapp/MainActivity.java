package edu.ritindia.prathmeshb.calulatorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static android.app.ProgressDialog.show;

public class MainActivity extends AppCompatActivity implements OnClickListener {

    Button addbtn, Subbtnn, Multiplybtnn, Dividebtnn;
    EditText ed_Num1;
    EditText ed_Num2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addbtn = findViewById(R.id.btn1);
        Subbtnn = findViewById(R.id.Subbtn);
        Multiplybtnn = findViewById(R.id.Multiplybtn);
        Dividebtnn = findViewById(R.id.Dividebtn);
        ed_Num1 = findViewById(R.id.Num1);
        ed_Num2 = findViewById(R.id.Num2);

        addbtn.setOnClickListener(this);
        Subbtnn.setOnClickListener(this);
        Multiplybtnn.setOnClickListener(this);
        Dividebtnn.setOnClickListener(this);

    }


    public void onClick(View v) {
        int id = v.getId();

        int n1=Integer.parseInt(ed_Num1.getText().toString());
        int n2=Integer.parseInt(ed_Num2.getText().toString());

        switch(id)

        {

            case R.id.btn1:
                Toast.makeText(getApplicationContext(), "Addition=" + (n1 + n2), Toast.LENGTH_LONG).show();
                break;

            case R.id.Subbtn:
                Toast.makeText(getApplicationContext(), "Subtraction=" + (n1 - n2), Toast.LENGTH_LONG).show();
                break;

            case R.id.Dividebtn:
                Toast.makeText(getApplicationContext(), "Division=" + (n1 / n2), Toast.LENGTH_LONG).show();
                break;

            case R.id.Multiplybtn:
                Toast.makeText(getApplicationContext(), "Multiplication=" + (n1 * n2), Toast.LENGTH_LONG).show();
                break;
        }


    }
}




