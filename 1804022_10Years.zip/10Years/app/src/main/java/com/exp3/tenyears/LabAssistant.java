package com.exp3.tenyears;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

public class LabAssistant extends AppCompatActivity {
    ImageView imageViewla;
    ImageButton imageButtonla;
    Button buttonla;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab_assistant);

        imageViewla=findViewById(R.id.imageViewla);
        imageButtonla=findViewById(R.id.imageButtonla);
        buttonla=findViewById(R.id.buttonla);

        imageButtonla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageViewla.setImageResource(R.drawable.prithvi);
            }
        });

        buttonla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i=new Intent(LabAssistant.this, MainActivity.class);
                startActivity(i);
            }
        });
    }
}