package com.example.quiz_appliction;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class ThirdActivity extends AppCompatActivity {

    Button btn;
    RadioButton Rbutton;
    RadioGroup Rgroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        btn = findViewById(R.id.button3);
        Rgroup = findViewById(R.id.radioGroup3);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int id = Rgroup.getCheckedRadioButtonId();
                Rbutton = findViewById(id);

                switch (id){

                    case R.id.radioButton5:
                        Toast.makeText(getApplicationContext(), "Correct Answer", Toast.LENGTH_SHORT).show();
                        MainActivity p = new MainActivity();
                        p.cnt = p.cnt+1;
                        startActivity(new Intent(getApplicationContext(), Result.class));
                        break;
                    case R.id.radioButton6:
                        Toast.makeText(getApplicationContext(), "Wrong Answer", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), Result.class));
                        break;
                    case R.id.radioButton7:
                        Toast.makeText(getApplicationContext(), "Wrong Answer", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), Result.class));
                        break;
                    case R.id.radioButton8:
                        Toast.makeText(getApplicationContext(), "Wrong Answer", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), Result.class));
                        break;
                }

            }
        });
    }
}