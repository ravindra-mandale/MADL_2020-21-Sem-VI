package com.example.quiz_appliction;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Result extends AppCompatActivity {

    TextView textView_result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        textView_result = findViewById(R.id.textView_result);

        MainActivity p = new MainActivity();

        String game = Integer.toString(p.cnt);

        textView_result.setText(game);
    }
}