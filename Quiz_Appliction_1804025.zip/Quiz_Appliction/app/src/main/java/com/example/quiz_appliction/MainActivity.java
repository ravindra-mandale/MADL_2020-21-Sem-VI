package com.example.quiz_appliction;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button button;
    RadioGroup rg;
    RadioButton rb;
    public static int cnt = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button_two);
        rg = findViewById(R.id.rg);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id = rg.getCheckedRadioButtonId();
                rb = findViewById(id);

                switch (id){
                    case R.id.rb1_seond:
                        Toast.makeText(MainActivity.this, "Wrong Answer", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(),secondFrame.class));
                        break;
                    case R.id.rb2_second:
                        Toast.makeText(MainActivity.this, "correct Answer", Toast.LENGTH_SHORT).show();
                        cnt = cnt + 1;
                        startActivity(new Intent(getApplicationContext(),secondFrame.class));
                        break;
                    case R.id.rb3_second:
                        Toast.makeText(MainActivity.this, "Wrong Answer", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(),secondFrame.class));
                        break;
                    case R.id.rb4_second:
                        Toast.makeText(MainActivity.this, "Wrong Answer", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(),secondFrame.class));
                        break;
                    default:
                        break;
                }
            }
        });

    }
}