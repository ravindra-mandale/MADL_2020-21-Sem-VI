package com.example.quiz_appliction;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class secondFrame extends AppCompatActivity {

    Button btn;
    RadioGroup Rgroup;
    RadioButton Rbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_frame);

        btn = findViewById(R.id.button_two);
        Rgroup = findViewById(R.id.radio_group2);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int id = Rgroup.getCheckedRadioButtonId();
                Rbutton = findViewById(id);

                switch (id){
                    case R.id.radioButton:
                        Toast.makeText(getApplicationContext(), "Wrong Answer", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(),ThirdActivity.class));
                        break;
                    case R.id.radioButton2:
                        Toast.makeText(getApplicationContext(), "Wrong Answer", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(),ThirdActivity.class));
                        break;
                    case R.id.radioButton3:
                        Toast.makeText(getApplicationContext(), "Correct Answer", Toast.LENGTH_SHORT).show();
                        MainActivity p = new MainActivity();
                        p.cnt = p.cnt+1;
                        startActivity(new Intent(getApplicationContext(),ThirdActivity.class));
                        break;
                    case R.id.radioButton4:
                        Toast.makeText(getApplicationContext(), "Wrong Answer", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(),ThirdActivity.class));
                        break;
                    default:
                        break;
                }

            }
        });

    }
}