package edu.ritindia.a10yearchallange;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Student extends AppCompatActivity {
    Button btn4,btn1;
    ImageView image_s;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        btn4=findViewById(R.id.button4);
        btn1=findViewById(R.id.button1);
        image_s=findViewById(R.id.imageView);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                image_s.setImageResource(R.drawable.student1);

            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent I4=new Intent(Student.this,MainActivity.class);
                startActivity(I4);

            }
        });
    }
}