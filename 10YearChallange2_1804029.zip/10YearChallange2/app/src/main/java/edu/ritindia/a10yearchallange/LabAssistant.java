package edu.ritindia.a10yearchallange;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class LabAssistant extends AppCompatActivity {
    Button btn5,btn1;
    ImageView image_l;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab_assistant);
        btn5=findViewById(R.id.button5);
        btn1=findViewById(R.id.button1);
        image_l=findViewById(R.id.imageView2);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                image_l.setImageResource(R.drawable.labassistant1);
            }
        });

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent I5=new Intent(LabAssistant.this,MainActivity.class);
                startActivity(I5);
            }
        });
    }
}