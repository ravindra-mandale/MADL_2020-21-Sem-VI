package edu.ritindia.a10yearchallange;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    String Role[] = {"Faculty", "Student", "LabAssistant"};
    Button btn, btn1;
    EditText Ed1, Ed2;
    Spinner spinner1;
    ArrayAdapter<String> arrayAdapter;
    String role, Entered_name,Entered_Password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Ed1 = findViewById(R.id.name1);
        Ed2 = findViewById(R.id.pswd1);
        btn = findViewById(R.id.button);
        btn1 = findViewById(R.id.button2);
        spinner1 = findViewById(R.id.spinner);
        arrayAdapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_item, Role);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(arrayAdapter);

        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                role = Role[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }

        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Entered_name = Ed1.getText().toString();
                Entered_Password = Ed2.getText().toString();
                switch (role) {
                    case "Faculty":
                        if (Entered_name.equals(Entered_Password)&&Entered_Password.equals(Entered_name)) {
                            Intent I = new Intent(MainActivity.this, Faculty.class);
                            startActivity(I);
                        }
                        else {
                            Toast.makeText(MainActivity.this, "Please Enter Correct Username or Password ", Toast.LENGTH_SHORT).show();
                        }
                        break;

                    case "Student":
                        if (Entered_name.equals(Entered_Password)&&Entered_Password.equals(Entered_name)) {
                            Intent I1 = new Intent(MainActivity.this, Student.class);
                            startActivity(I1);
                        }
                        else{
                            Toast.makeText(MainActivity.this, "Please Enter Correct Username or Password ", Toast.LENGTH_SHORT).show();
                        }
                        break;

                    case "LabAssistant":
                        if (Entered_name.equals(Entered_Password)&&Entered_Password.equals(Entered_name)) {


                            Intent I3 = new Intent(MainActivity.this, LabAssistant.class);
                            startActivity(I3);
                        }
                        else {
                            Toast.makeText(MainActivity.this, "Please Enter Correct Username or Password ", Toast.LENGTH_SHORT).show();
                        }
                        break;


                }


            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Ed1.setText("");
                Ed2.setText("");
            }
        });

    }
}