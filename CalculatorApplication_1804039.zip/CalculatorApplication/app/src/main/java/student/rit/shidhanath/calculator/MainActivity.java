package student.rit.shidhanath.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText FirstNumber, SecondNumber;
    TextView result;
    Button add,sub,mul,div;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FirstNumber=findViewById(R.id.etFirstNumber);
        SecondNumber=findViewById(R.id.etSecondNumber);
        result=findViewById(R.id.ptresult);
        add=findViewById(R.id.btadd);
        sub=findViewById(R.id.btsub);
        mul=findViewById(R.id.btmul);
        div=findViewById(R.id.btdiv);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int firstvalue, secondValue,ans;
                firstvalue=Integer.parseInt(FirstNumber.getText().toString());
                secondValue=Integer.parseInt(SecondNumber.getText().toString());
                ans=firstvalue + secondValue;
                result.setText("Addition is = "+ans);

            }
        });

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int firstvalue,secondvalue,ans;
                firstvalue=Integer.parseInt(FirstNumber.getText().toString());
                secondvalue=Integer.parseInt(SecondNumber.getText().toString());
                ans=firstvalue - secondvalue;
                result.setText("Substraction is = "+ans);
            }
        });

        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int firstvalue,secondvalue,ans;
                firstvalue=Integer.parseInt(FirstNumber.getText().toString());
                secondvalue=Integer.parseInt(SecondNumber.getText().toString());
                ans=firstvalue * secondvalue;
                result.setText("Multiplication is = "+ans);
            }
        });

        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int firstvalue,secondvalue,ans;
                firstvalue=Integer.parseInt(FirstNumber.getText().toString());
                secondvalue=Integer.parseInt(SecondNumber.getText().toString());
                ans=firstvalue / secondvalue;
                result.setText("Division is = "+ans);
            }
        });

    }
}