package com.example.sqlliteproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class login extends AppCompatActivity {

    EditText loginUser, password;
    Button register, login;
    TextView textView;

    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginUser = findViewById(R.id.loginUser);
        password = findViewById(R.id.loginPassword);

        register = findViewById(R.id.registerBtn);
        login = findViewById(R.id.loginBtn);
        textView = findViewById(R.id.textView2);

        DB = new DBHelper(this);

        textView.setTranslationX(800);
        login.setTranslationX(800);
        register.setTranslationX(-800);
        loginUser.setTranslationX(800);
        password.setTranslationX(-800);

        textView.setAlpha(0);
        login.setAlpha(0);
        register.setAlpha(0);
        loginUser.setAlpha(0);
        password.setAlpha(0);

        textView.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(300).start();
        loginUser.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        password.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(700).start();
        login.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(900).start();
        register.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(1100).start();



        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = loginUser.getText().toString().trim();
                String pass = password.getText().toString().trim();

                if(user.isEmpty()){
                    loginUser.setError("Required Field!");
                    return;
                }
                if(pass.isEmpty()){
                    password.setError("Required Field!");
                    return;
                }

                Boolean checkuserpass = DB.checkusernamepassword(user, pass);
                if(checkuserpass==true){
                    Toast.makeText(login.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), Dashboard.class));
                    finish();
                }else {
                    Toast.makeText(login.this, "Invalid Credentials !", Toast.LENGTH_SHORT).show();
                }


            }
        });


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });
    }
}