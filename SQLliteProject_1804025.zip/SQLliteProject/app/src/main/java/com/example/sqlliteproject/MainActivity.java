package com.example.sqlliteproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText name, pass, number;
    Button loginBtn, registerBtn;
    TextView textView;

    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.email);
        pass = findViewById(R.id.password);
        number = findViewById(R.id.number);
        textView = findViewById(R.id.textView3);
        loginBtn = findViewById(R.id.login);
        registerBtn = findViewById(R.id.register);

        DB = new DBHelper(this);

        textView.setTranslationX(-800);
        name.setTranslationX(800);
        pass.setTranslationX(-800);
        number.setTranslationX(800);
        loginBtn.setTranslationX(-800);
        registerBtn.setTranslationX(800);

        textView.setAlpha(0);
        name.setAlpha(0);
        pass.setAlpha(0);
        number.setAlpha(0);
        loginBtn.setAlpha(0);
        registerBtn.setAlpha(0);

        textView.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(300).start();
        name.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        pass.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(700).start();
        number.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(900).start();
        loginBtn.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(1100).start();
        registerBtn.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(1300).start();

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = name.getText().toString().trim();
                String password = pass.getText().toString().trim();
                String mobile = number.getText().toString().trim();

                if(user.isEmpty()){
                    name.setError("Required Field!");
                    return;
                }
                if(password.isEmpty()){
                    pass.setError("Required Field!");
                    return;
                }
                if(mobile.isEmpty()){
                    number.setError("Required Field!");
                    return;
                }
                if(mobile.length()!=10){
                    number.setError("Mobile number length should have 10!");
                    return;
                }


                Boolean checkuser = DB.checkusername(user);
                if(checkuser==false){
                    Boolean insert = DB.insertData(user, password, mobile);
                    if(insert==true){
                        Toast.makeText(MainActivity.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), login.class));
                        finish();
                    }else {
                        Toast.makeText(MainActivity.this, "Something went Wrong", Toast.LENGTH_SHORT).show();

                    }
                }else {
                    Toast.makeText(MainActivity.this, "User Already exists!", Toast.LENGTH_SHORT).show();
                }

            }
        });


        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), login.class));
            }
        });

    }
}