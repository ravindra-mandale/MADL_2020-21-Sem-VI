package com.example.intentdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.bluetooth.BluetoothClass;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Browser;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.service.media.MediaBrowserService;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.net.URI;
import java.security.Provider;

public class MainActivity extends AppCompatActivity {

    EditText number;
    Button call, dialpad, contact, browser, calllog, gallery, camera;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        call = findViewById(R.id.call);
        dialpad = findViewById(R.id.dialpad);
        contact = findViewById(R.id.contact);
        browser = findViewById(R.id.browser);
        calllog = findViewById(R.id.callLog);
        gallery = findViewById(R.id.gallery);
        camera = findViewById(R.id.camera);

        number = findViewById(R.id.phoneNumber);

        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = number.getText().toString();
                if(phoneNumber.isEmpty()){
                    number.setError("Please Enter valid Phone Number!");
                    return;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+phoneNumber)));
                }catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(getApplicationContext(), "Could not find an activity to place the call.",Toast.LENGTH_SHORT).show();
                }

            }
        });


        dialpad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_DIAL));
            }
        });

        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI));
            }
        });

        browser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_VIEW , Uri.parse("http://www.google.com")));
            }
        });

        calllog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.setType(CallLog.Calls.CONTENT_TYPE);
                startActivity(intent);
            }
        });

        gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
                final int ACTIVITY_SELECT_IMAGE = 1234;
                startActivityForResult(i, ACTIVITY_SELECT_IMAGE);
            }
        });

        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MediaStore.ACTION_IMAGE_CAPTURE));
            }
        });


    }
}