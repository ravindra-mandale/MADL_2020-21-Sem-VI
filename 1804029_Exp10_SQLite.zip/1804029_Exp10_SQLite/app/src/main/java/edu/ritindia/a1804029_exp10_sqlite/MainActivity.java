package edu.ritindia.a1804029_exp10_sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText eduser, edpass;
    Button btregister, btlogin, btdelete, btupdate;
    myHelper myHelper ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myHelper = new myHelper(MainActivity.this);
        setContentView(R.layout.activity_main);
        eduser = findViewById(R.id.ed_user);
        edpass = findViewById(R.id.ed_pass);

        btregister = findViewById(R.id.Register);
        btlogin = findViewById(R.id.Login);
        btdelete = findViewById(R.id.Delete);
        btupdate = findViewById(R.id.Update);


        btregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,Registeration.class);
                startActivity(i);
            }
        });

        btlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myHelper=new myHelper(MainActivity.this);
                Cursor cr1 = myHelper.selectdata();
                StringBuilder sb =new StringBuilder();
                if((eduser.getText().toString()).equals("")){
                    eduser.setError("Can't Empty");
                }
                else if((edpass.getText().toString()).equals("")){
                    edpass.setError("Can't Empty");
                }else if(cr1.moveToFirst())
                {
                    do{
                        String un=eduser.getText().toString();
                        String pwd=edpass.getText().toString();
                        if(un.equals(cr1.getString(1))&&(pwd.equals(cr1.getString(2)))){
                            Toast.makeText(getApplicationContext(),"Login Successfully",Toast.LENGTH_LONG).show();
                            Intent i1=new Intent(MainActivity.this,Welcome.class);
                            i1.putExtra("Username",un);
                            startActivity(i1);
                        }
                        else {
                            Toast.makeText(getApplicationContext(),"Enter valid Username or Password",Toast.LENGTH_LONG).show();
                        }
                    }while(cr1.moveToNext());
                }
                else {
                    Toast.makeText(getApplicationContext(), "No Record Found", Toast.LENGTH_LONG).show();
                }
                eduser.setText("");
                edpass.setText("");
            }
        });

        btdelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String un=eduser.getText().toString();
                boolean value=myHelper.deletedata(un);
                if((eduser.getText().toString()).equals("")){
                    eduser.setError("Can't Empty");
                }
                else if((edpass.getText().toString()).equals("")){
                    edpass.setError("Can't Empty");
                }else if(value) {
                    Toast.makeText(getApplicationContext(), "Deleted Successfully", Toast.LENGTH_LONG).show();
                } else{
                    Toast.makeText(getApplicationContext(), "Not Deleted", Toast.LENGTH_LONG).show();
                }
                eduser.setText("");
                edpass.setText("");
            }
        });

        btupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String un=eduser.getText().toString();
                String pwd=edpass.getText().toString();
                boolean value= myHelper.updatedata(un,pwd);
                if((eduser.getText().toString()).equals("")){
                    eduser.setError("Can't Empty");
                }
                else if((edpass.getText().toString()).equals("")){
                    edpass.setError("Can't Empty");
                }else if(value) {
                    Toast.makeText(getApplicationContext(), "Updated Successfully", Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getApplicationContext(), "Not Updated", Toast.LENGTH_LONG).show();
                }
                eduser.setText("");
                edpass.setText("");
            }
        });
    }
}
