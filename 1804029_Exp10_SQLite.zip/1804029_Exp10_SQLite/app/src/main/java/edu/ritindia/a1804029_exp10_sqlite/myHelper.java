package edu.ritindia.a1804029_exp10_sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class myHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME="RIT.db";
    public static final String TABLE_NAME="Student";

    public myHelper(Context context)
    {
        super(context,"RIT.db",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table "+TABLE_NAME+" (rollno int, Username varchar(20), Password varchar(20))");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("drop table if exists "+TABLE_NAME+"");
        onCreate(db);


    }

    public boolean insertdata(int rn, String u, String p) {


        ContentValues values = new ContentValues();
        values.put("rollno", rn);
        values.put("Username", u);
        values.put("Password",p);
        SQLiteDatabase db = getWritableDatabase();
        db.insertOrThrow(TABLE_NAME, null, values);
        return true;

    }

    public Cursor selectdata()
    {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cr = db.rawQuery("select * from "+TABLE_NAME+"",null);
        return cr;

    }
    public boolean deletedata(String un1)
    {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_NAME,"Username=?",new String[]{un1});
        return true;
    }
    public boolean updatedata(String un1, String pwd1)
    {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Username",un1);
        values.put("Password",pwd1);
        db.update(TABLE_NAME,values,"Username=?",new String[]{un1});
        return true;
    }


}

