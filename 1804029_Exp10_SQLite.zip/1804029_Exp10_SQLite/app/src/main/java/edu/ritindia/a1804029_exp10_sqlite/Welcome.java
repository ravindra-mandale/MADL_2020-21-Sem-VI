package edu.ritindia.a1804029_exp10_sqlite;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Welcome extends AppCompatActivity {

    Button logout;
    TextView t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        logout=findViewById(R.id.Logout);
        t1=findViewById(R.id.User);

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent I2=new Intent(edu.ritindia.a1804029_exp10_sqlite.Welcome.this, MainActivity.class);
                startActivity(I2);
                Toast.makeText(getApplicationContext(), "Logout Successfully", Toast.LENGTH_LONG).show();
            }
        });
        Intent intent=getIntent();
        String UName=intent.getStringExtra("Username");
        t1.setText(UName +" is username");
    }
}