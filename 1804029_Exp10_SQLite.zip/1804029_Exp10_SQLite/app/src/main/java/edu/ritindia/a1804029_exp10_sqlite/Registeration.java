package edu.ritindia.a1804029_exp10_sqlite;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Registeration extends AppCompatActivity {

    Button button_reg, button_clear;
    EditText ed_rolln,ed_username,ed_password;
    myHelper myHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registeration);
        myHelper=new myHelper(edu.ritindia.a1804029_exp10_sqlite.Registeration.this);
        ed_rolln=findViewById(R.id.ed_roll);
        ed_username=findViewById(R.id.ed_user2);
        ed_password=findViewById(R.id.ed_pass2);
        button_reg=findViewById(R.id.Register2);
        button_clear=findViewById(R.id.Clear);

        button_clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed_rolln.setText("");
                ed_username.setText("");
                ed_password.setText("");
            }
        });

        button_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if((ed_rolln.getText().toString()).equals("")){
                    ed_rolln.setError("Can't Empty");
                }
                else if((ed_username.getText().toString()).equals("")){
                    ed_username.setError("Can't Empty");
                }
                else if((ed_password.getText().toString()).equals("")){
                    ed_password.setError("Can't Empty");
                }else{
                    int rn=Integer.parseInt(ed_rolln.getText().toString());
                    String un=ed_username.getText().toString();
                    String pwd=ed_password.getText().toString();
                    myHelper.insertdata(rn,un,pwd);
                    Toast.makeText(getApplicationContext(),"Registration completed", Toast.LENGTH_LONG).show();
                }
                Intent i=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(i);
                finish();
            }
        });

    }
}