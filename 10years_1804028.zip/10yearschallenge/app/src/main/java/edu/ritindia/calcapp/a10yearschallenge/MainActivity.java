 package edu.ritindia.calcapp.a10yearschallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

 public class MainActivity extends AppCompatActivity {
    String[] status ={"Student","Faculty","LabAssistant"};
    String fun="gaikwad", fp="abhishek",su="ankit",sp="raminwar",lu="akash",lp="patil",text="";
    EditText un,pass;
    Button log,can;
    ArrayAdapter<String> aa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Spinner spinn = findViewById(R.id.spinner);
        un=findViewById(R.id.username);
        pass=findViewById(R.id.password);
        log=findViewById(R.id.login);
        can=findViewById(R.id.cancle);



        aa=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,status);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinn.setAdapter(aa);
        spinn.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                text = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(text.equals("Student") && un.getText().toString().equals(su) && pass.getText().toString().equals(sp))
                {
                    Intent j = new Intent(MainActivity.this,student.class);
                    startActivity(j);
                    Toast.makeText(getApplicationContext(),"this",Toast.LENGTH_LONG).show();
                }

                else if(text.equals("Faculty") && un.getText().toString().equals(fun) && pass.getText().toString().equals(fp))
                {
                    Intent i = new Intent(MainActivity.this,faulty.class);
                    startActivity(i);
                    Toast.makeText(getApplicationContext(),"this",Toast.LENGTH_LONG).show();
                }
                else if(text.equals("LabAssistant") && un.getText().toString().equals(lu) && pass.getText().toString().equals(lp))
                {
                    Intent k = new Intent(MainActivity.this,labas.class);
                    startActivity(k);
                    Toast.makeText(getApplicationContext(),"this",Toast.LENGTH_LONG).show();
                }

            }
        });
        can.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                un.setText("");
                pass.setText("");
            }
        });


    }
}