package esu.exp3.madlab.androidquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class Q2 extends AppCompatActivity {
    RadioButton rb31,rb32,rb33,rb34;
    RadioGroup rg3;
    FloatingActionButton fb1;
    Intent i3;
    int result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q2);

        i3=getIntent();
        result=i3.getIntExtra("Result",0);


        rb31=findViewById(R.id.rb31);
        rb32=findViewById(R.id.rb32);
        rb33=findViewById(R.id.rb33);
        rb34=findViewById(R.id.rb34);
        rg3=findViewById(R.id.rg3);
        fb1=findViewById(R.id.fb1);

        fb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int rgid=rg3.getCheckedRadioButtonId();

                if(R.id.rb34==rgid)
                {
                    result=result+5;
                    Snackbar.make(v," Your score is  " +result+" out of 15 ",Snackbar.LENGTH_LONG).setAction("End", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Toast.makeText(getApplicationContext(),"Thank You",Toast.LENGTH_LONG).show();
                            Intent i=new Intent(Q2.this,MainActivity.class);
                            startActivity(i);
                        }
                    }).show();


                }
                else
                {
                    Snackbar.make(v," Your score is  " +result+" out of 15 ",Snackbar.LENGTH_LONG).setAction("End", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Toast.makeText(getApplicationContext(),"Thank You",Toast.LENGTH_LONG).show();
                            Intent i=new Intent(Q2.this,MainActivity.class);
                            startActivity(i);
                        }
                    }).show();


                }

               



            }
        });

    }
}