package esu.exp3.madlab.androidquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.android.material.snackbar.Snackbar;

public class Q1 extends AppCompatActivity {

    RadioButton rb21,rb22,rb23,rb24;
    RadioGroup rg2;
    Button bt2;
    Intent i2;
    int result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q1);

        i2=getIntent();
        result=i2.getIntExtra("Result",0);


        rb21=findViewById(R.id.rb21);
        rb22=findViewById(R.id.rb22);
        rb23=findViewById(R.id.rb23);
        rb24=findViewById(R.id.rb24);
        rg2=findViewById(R.id.rg2);
        bt2=findViewById(R.id.bt2);




        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int rgid1=rg2.getCheckedRadioButtonId();

                if(R.id.rb21==rgid1)
                {
                    result=result+5;
                }

                Intent i=new Intent(Q1.this, Q2.class);
                i.putExtra("Result",result);
                startActivity(i);



            }
        });




    }
}