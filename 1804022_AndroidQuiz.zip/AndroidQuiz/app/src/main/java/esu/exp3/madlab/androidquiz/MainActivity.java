package esu.exp3.madlab.androidquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    RadioButton rb11,rb12,rb13,rb14;
    RadioGroup rg1;
    Button bt1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rb11=findViewById(R.id.rb11);
        rb12=findViewById(R.id.rb12);
        rb13=findViewById(R.id.rb13);
        rb14=findViewById(R.id.rb14);
        rg1=findViewById(R.id.rg1);
        bt1=findViewById(R.id.bt1);


        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int rgid=rg1.getCheckedRadioButtonId();
                int result=0;
                if(R.id.rb12==rgid)
                {
                    result=result+5;
                }

                Intent i=new Intent(MainActivity.this,Q1.class);
                i.putExtra("Result",result);
                startActivity(i);



            }
        });





    }
}