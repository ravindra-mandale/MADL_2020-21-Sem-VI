package edu.ritindia.siddhant.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button cal;
    EditText ht, wt;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        cal=findViewById(R.id.button);
        result=findViewById(R.id.textView5);
        wt=findViewById(R.id.editTextNumber);
        ht=findViewById(R.id.height);

        cal.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String str1, str2;
                    str1= wt.getText().toString();
                    str2= ht.getText().toString();

                    if(str1.isEmpty())
                    {
                        wt.setError("Please Enter Valid Number");
                        return;
                    }
                    if(str2.isEmpty())
                    {
                        ht.setError("Please Enter Valid Number");
                        return;
                    }

                    double a = Double.parseDouble(str1);
                    double b = Double.parseDouble(str2);
                    double Result = ((a/b)/b);
                    double Res= Math.round(Result*10000);
                    String sol=Double.toString(Res);
                    if (Res < 18.5) {
                        result.setText(sol+"-UnderWeight");
                    }else
                    {
                        if(Res > 25) {
                            result.setText(sol+"-OverWeight");
                        }
                        result.setText(sol+"-Normal Weight");
                    }
                }
            });

        }
}