package in.akash.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText heightBox, weightBox;
    private Button calculateButton, clearButton;
    private TextView resultsText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        heightBox = findViewById(R.id.textHeight);
        weightBox = findViewById(R.id.textWeight);

        resultsText = findViewById(R.id.resultLabel);

        calculateButton = findViewById(R.id.buttonCalculate);
        clearButton = findViewById(R.id.buttonClear);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float weight = Float.parseFloat(weightBox.getText().toString());
                float height = Float.parseFloat(heightBox.getText().toString());

                String results = getComment(getBMI(weight, height));

                resultsText.setText(results);

            }
        });

        clearButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                heightBox.setText("");
                weightBox.setText("");
            }
        });
    }

    private double getBMI(float weight, float height)
    {
        // Data validation
        float w = weight;
        float h = height;
        // BMI formula
        double bmi = (w / h / h) * 10000;
        return bmi;
    }

    private String getComment(double bmi)
    {
        String results = String.valueOf((int) bmi);

        if (bmi >= 30)
        {
            results = results.concat("- Obesity is possible. Go for gym!");
        }
        else if (bmi >= 25)
        {
            results = results.concat("- You may go obese one. Be careful with your diet!!");
        }
        else if (bmi >= 18)
        {
            results = results.concat("- You're under control. Try skipping junkies!");
        }
        else
        {
            results = results.concat("- Oh! You're under weight.. Eat healthy food, do exercise!");
        }
        return results;
    }
}