package edu.ritindia.a1804029_exp9_file;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.os.Environment;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

public class MainActivity extends AppCompatActivity  {

    Button b1,b2,b3,b4;
    EditText e1;
    TextView t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        b3=findViewById(R.id.button3);
        b4=findViewById(R.id.button4);
        e1=findViewById(R.id.editText);
        t1=findViewById(R.id.textView);
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
        checkExternalMedia();

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String name=e1.getText().toString();
                try
                {
                    OutputStreamWriter osw=new OutputStreamWriter(openFileOutput("android.txt",MODE_APPEND));
                    osw.write(name);
                    Toast.makeText(MainActivity.this,"Saved To "+getFilesDir(),Toast.LENGTH_LONG).show();
                    osw.close();
                    Toast.makeText(MainActivity.this, "File written successfully", Toast.LENGTH_LONG).show();

                }
                catch(IOException e)
                {
                    Toast.makeText(MainActivity.this, "File cannot be written", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try
                {
                    InputStreamReader ir=new InputStreamReader(openFileInput("android.txt"));
                    BufferedReader br= new BufferedReader(ir);
                    String data=br.readLine();
                    t1.setText(data);

                } catch(FileNotFoundException e){
                    e.printStackTrace();
                } catch(IOException e)
                {
                    Toast.makeText(MainActivity.this, "Can't read file", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String name=e1.getText().toString();
                try {
                    File root = Environment.getExternalStorageDirectory();
                    File dir = new File (root.getAbsolutePath() );
                    File file = new File(dir, "myData1.txt");
                    FileOutputStream f = new FileOutputStream(file);
                    //f.write(Integer.parseInt(name));
                    PrintWriter pw = new PrintWriter(f);
                    pw.println(e1.getText());
                    pw.flush();
                    pw.close();
                    f.close();
                    Toast.makeText(MainActivity.this, "File written successfully to "+dir.toString(), Toast.LENGTH_SHORT).show();
                }
                catch (IOException e) {
                    Toast.makeText(MainActivity.this, "Can't write file", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }

            }


        });


        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                try
                {
                    File root = android.os.Environment.getExternalStorageDirectory();
                    File dir = new File (root.getAbsolutePath() );
                    File file = new File(dir, "myData1.txt");
                    FileReader pw = new FileReader(file);
                    BufferedReader br= new BufferedReader(pw);
                    t1.setText(br.readLine());
                } catch (FileNotFoundException e)
                {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, "Can't read file", Toast.LENGTH_SHORT).show();
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }

            }


        });


    }
    private void checkExternalMedia() {
        boolean mExternalStorageAvailable = false;
        boolean mExternalStorageWriteable = false;
        String state = Environment.getExternalStorageState();

        if (Environment.MEDIA_MOUNTED.equals(state)) {
            // Can read and write the media
            mExternalStorageAvailable = mExternalStorageWriteable = true;
        } else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            // Can only read the media
            mExternalStorageAvailable = true;
            mExternalStorageWriteable = false;
        } else {
            // Can't read or write
            mExternalStorageAvailable = mExternalStorageWriteable = false;
        }
    }
}
