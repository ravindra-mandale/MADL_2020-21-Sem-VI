package com.example.views;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText height, weight;
    Button calculateBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        height = findViewById(R.id.height);
        weight = findViewById(R.id.weight);

        calculateBtn = findViewById(R.id.calculate);

        calculateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ht, wt;

                ht = height.getText().toString();
                wt = weight.getText().toString();

                if(ht.isEmpty()){
                    height.setError("Please enter valid Height");
                    return;
                }

                if(wt.isEmpty()){
                    weight.setError("Please enter valid Weight");
                    return;
                }


                double a = Double.parseDouble(ht);
                double b = Double.parseDouble(wt);

                double solution = b / (a*a);
                String result = Double.toString(solution);

                Toast.makeText(getApplicationContext(),result,Toast.LENGTH_LONG).show();

            }
        });

    }
}