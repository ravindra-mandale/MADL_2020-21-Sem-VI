package edu.rit.samruddhi.quizeapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class Que3 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_que3);
        Intent i=getIntent();
        int ans1=i.getIntExtra("Value1",0);
        int ans2=i.getIntExtra("Value2",0);
        TextView que3, que;
        RadioGroup rg;
        RadioButton b;
        Button next;
        que3 = findViewById(R.id.textView6);
        que = findViewById(R.id.textView7);
        rg = findViewById(R.id.radiogroup3);
        next = findViewById(R.id.button2);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int result=0;
                int selected3 = rg.getCheckedRadioButtonId();
                if(ans1==R.id.radioButton2)
                {
                    result=result+10;
                }
                if(ans2==R.id.radioButton6);
                {
                    result=result+10;
                }
                if(selected3==R.id.radioButton9)
                {
                    result=result+10;
                }
                Toast.makeText(getApplicationContext(),"Your score is:"+result,Toast.LENGTH_LONG).show();
                startActivity(i);
            }
        });

    }
}