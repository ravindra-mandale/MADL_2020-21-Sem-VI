package edu.rit.samruddhi.quizeapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class Que2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_que2);
        Intent i=getIntent();
        int pass=i.getIntExtra("Value1",0);
        TextView que2, que;
        RadioGroup rg;
        RadioButton b;
        Button next;
        que2 = findViewById(R.id.textView4);
        que = findViewById(R.id.textView5);
        rg = findViewById(R.id.radiogroup2);
        next = findViewById(R.id.button3);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selected2 = rg.getCheckedRadioButtonId();
                Intent i = new Intent(Que2.this, Que3.class);
                i.putExtra("Value1",pass);
                i.putExtra("Value2", selected2);
                startActivity(i);
            }
        });
    }
}