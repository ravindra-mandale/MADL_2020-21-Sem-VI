package edu.rit.samruddhi.quizeapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class Que1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_que1);
        TextView que1, que;
        RadioGroup rg;
        RadioButton b;
        Button next;
        que1 = findViewById(R.id.textView1);
        que = findViewById(R.id.textView2);
        rg = findViewById(R.id.radiogroup1);
        next = findViewById(R.id.button1);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selected1 = rg.getCheckedRadioButtonId();
                Intent i = new Intent(Que1.this, Que2.class);
                i.putExtra("Value1", selected1);
                startActivity(i);
            }
        });
    }

    }