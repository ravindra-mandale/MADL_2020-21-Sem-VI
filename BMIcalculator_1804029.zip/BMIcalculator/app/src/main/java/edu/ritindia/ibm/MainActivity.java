package edu.ritindia.ibm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText Ed1,Ed2;
    Button btn1;
    String a,b,ans;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Ed1=findViewById(R.id.Edit1);
        Ed2=findViewById(R.id.Edit2);
        btn1=findViewById(R.id.button);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str1=Ed1.getText().toString();
                String str2=Ed2.getText().toString();

                float weight=Float.parseFloat(str1);
                float height=Float.parseFloat(str2);



                float BMI=weight/(height*height);

                Toast.makeText(getApplicationContext(),"Your BMI is "+BMI,Toast.LENGTH_LONG).show();
            }
        });
    }
}