package edu.rit.sanajana.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener  {


    EditText ed1,ed2;
    Button btn1,btn2,btn3,btn4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.num1);
        ed2=findViewById(R.id.num2);
        btn1=findViewById(R.id.b1);
        btn2=findViewById(R.id.b2);
        btn3=findViewById(R.id.b3);
        btn4=findViewById(R.id.b4);

        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
    }
    public void onClick(View v)
    {
        int id=v.getId();
        int number1=Integer.parseInt(ed1.getText().toString());
        int number2=Integer.parseInt(ed2.getText().toString());
        switch (id)
        {
            case R.id.b1:
                Toast.makeText(getApplicationContext(),"Addition is :" +(number1+number2),Toast.LENGTH_LONG).show();
                break;
            case R.id.b2:
                Toast.makeText(getApplicationContext(),"Substraction is :" +(number1-number2),Toast.LENGTH_LONG).show();
                break;
            case R.id.b3:
                Toast.makeText(getApplicationContext(),"Multiplication is :" +(number1*number2),Toast.LENGTH_LONG).show();
                break;
            case R.id.b4:
                Toast.makeText(getApplicationContext(),"Division is :" +(number1/number2),Toast.LENGTH_LONG).show();
                break;


        }

    }
}