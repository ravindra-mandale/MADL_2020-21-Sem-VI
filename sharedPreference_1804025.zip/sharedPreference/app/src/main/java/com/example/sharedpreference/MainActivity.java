package com.example.sharedpreference;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button clear, store, retrive;
    TextView adharText, panText;
    EditText adharEdit, panEdit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        clear = findViewById(R.id.clear);
        store = findViewById(R.id.store);
        retrive = findViewById(R.id.retrive);

        adharText = findViewById(R.id.adharText);
        panText = findViewById(R.id.panText);

        adharEdit = findViewById(R.id.adhar);
        panEdit = findViewById(R.id.pan);


        store.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String adharMsg = adharEdit.getText().toString();
                String panMsg = panEdit.getText().toString();

                SharedPreferences shrd = getSharedPreferences("demo", MODE_PRIVATE);
                SharedPreferences.Editor editor = shrd.edit();

                editor.putString("adharKey",adharMsg );
                editor.putString("panKey",panMsg );

                editor.apply();
//                adharText.setText(adharMsg);
//                panText.setText(panMsg);

            }
        });


        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adharEdit.setText("");
                panEdit.setText("");
            }
        });

        retrive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences getShared = getSharedPreferences("demo", MODE_PRIVATE);
                String adharValue = getShared.getString("adharKey", "Save a Adhar Number");
                String panValue = getShared.getString("panKey", "Save a Pan Number");

                adharText.setText(adharValue);
                panText.setText(panValue);
            }
        });


    }
}